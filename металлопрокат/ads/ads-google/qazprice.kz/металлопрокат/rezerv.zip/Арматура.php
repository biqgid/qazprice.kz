<?php 

require './bootstrap.php';
require './php/mail.php';

//------------------------------------------------
$go = 'Арматура в Алматы';
if(isset($_GET['go'])){
	if($_GET['go'] == 'a3'){$go = 'Арматура А3';}
}
$hgo = 'Прайс лист на арматуру в Алматы';
if(isset($_GET['hgo'])){
	if($_GET['hgo'] == 'a4'){$hgo = 'Прайс лист';}
}
//https://qazprice.kz/metall/armatura?go=a3&hgo=a4
//------------------------------------------------
?>

<!doctype html>
<html lang="ru_RU">
	<html>
		<head>
			<meta charset="utf-8">
			<meta content="width=device-width, initial-scale=1.0" name="viewport">
			<title>Арматура в Алматы</title>

			<meta name="description" content="">
			<meta name="abstract" content="">
			<meta name="keywords" content="">

			<meta name="yandex-verification" content="" />
			<meta name="google-site-verification" content="" />

			<link rel="shortcut icon" type="image/x-icon" href="favicon/favicon.ico">

			<link rel="preload" href="./bootstrap.css" as="style" onload="this.rel='stylesheet'">


			<script src="./blocks/ppcalc/calkulator-zayavka/vue.js"></script>

			<script src="./library/jquery.min.js"></script>
			<script src="./library/bootstrap.min.js"></script>

		</head>
		<body>
			<header>
				<div class="label-place"></div> 
				<div id="navigation" class="navigation-bar">
					<? require './header.php'; ?>
				</div>
			</header>
			<? require './blocks/nav/nav.php'; ?>
			<div class="container">
				<div class="row">
					<div class="col-md-5">
						<img src="./img/armatura-frames/frame_13.png">
					</div>
					<div class="col-md-7">
						<h2><?php echo $go; ?></h2>
						<h3>Цены на арматуру в Алматый</h3>
						<b>Купить арматуру, цена за метр арматуры, цена за тонну арматуры.</b>
					</div>

				</div>
			</div>
			<hr>
			<div class="container">
				<div class="row">
					<div class="col-md-5">
						<? require './blocks/ppcalc/calkulator-zayavka/armatura-a3.php'; ?>
						<br>
						<script>
							function copyDiv() {
								var firstDivContent = document.getElementById('mydiv1');
								var secondDivContent = document.getElementById('mydiv2');
								secondDivContent.innerHTML = firstDivContent.innerHTML;
							}
							//Call copyDiv on body="onload"
							copyDiv();
						</script>
						
						<div id="mydiv2"></div>


						<div class="block">
							<b>CRM</b>
							<div class="tabs">
								<input type="radio" name="inset" value="" id="tab_3">
								<label for="tab_3"><span class="text-muted text-right">300 $</span></label>

								<input type="radio" name="inset" value="" id="tab_4">
								<label for="tab_4"><i class="fas fa-address-card"></i> +77015551073</label>

								<input type="radio" name="inset" value="" id="tab_5">
								<label for="tab_5">+</label>

								<div id="txt_3">
									<p>Форма оплаты: <b>наличными на выгрузке</b></p>
									<p>Варианты: <b>50/50</b></p>
								</div>
								<div id="txt_4">
									+<span class="phone">77015551073</span>
									<script>
										$(function()	{
											$('.phone').click(function(e)	{
												//ловим элемент, по которому кликнули
												var t = e.target || e.srcElement;
												//получаем название тега
												var elm_name = t.tagName.toLowerCase();
												//если это инпут - ничего не делаем
												if(elm_name == 'input')	{return false;}
												var val = $(this).html();
												var code = '<input type="text" id="edit" value="'+val+'" />';
												$(this).empty().append(code);
												$('#edit').focus();
												$('#edit').blur(function()	{
													var val = $(this).val();
													$(this).parent().empty().html(val);
												});
											});
										});
										$(window).keydown(function(event){
											//ловим событие нажатия клавиши
											if(event.keyCode == 13) {	//если это Enter
												$('#edit').blur();	//снимаем фокус с поля ввода
											}
										});
									</script>
									<a><svg class="svg-inline--fa fa-whatsapp fa-w-14" aria-hidden="true" data-prefix="fab" data-icon="whatsapp" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" data-fa-i2svg=""><path fill="currentColor" d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path></svg></a>

								</div>
							</div>
							<style type="text/css">
								.tabs { width: 100%; padding: 0px; margin: 0 auto; }
								.tabs>input { display:none; }
								.tabs>div { display: none;
									padding: 3px;
									border: 1px solid #C0C0C0;
									background: #FFFFFF;
								}
								.tabs>label {
									margin: 0;
									cursor: pointer;
								}
								.tabs>input:checked + label {
									color: #000000;
									border: 1px solid #C0C0C0;
									border-bottom: 1px solid #FFFFFF;
									background: #FFFFFF;
								}
								#tab_1:checked ~ #txt_1,
								#tab_2:checked ~ #txt_2,
								#tab_3:checked ~ #txt_3,
								#tab_4:checked ~ #txt_4,
								#tab_4:checked ~ #txt_5 { display: block; }
							</style> 
						</div>
						<div class="modal fade js-payment-modal" id="new-payment-modal" aria-hidden="true" style="display: none;">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
										<h2 class="modal-title">Добавить груз</h2>
									</div>
									<div class="modal-body clearfix">
										<div class="row">
											<div class="col-md-12">
												<input type="hidden" id="phone">                       
												<textarea name="message" placeholder="Текст"></textarea>
												<button class="btn-success go" style="display: block; margin-top: 5px;">
													Отправить на WhatsApp 
													<i class="fab fa-whatsapp">

													</i>
												</button>
												<script>


													$('body').on('click', '.fa-whatsapp', function() {

														var header = $(this).parent().siblings('.phone').text();

														header = header.replace(/\s/g, '');

														header = header.substring(1, header.length)


														$("#new-payment-modal").modal('show');
														$(".modal-title").text(header);
														$("#phone").val(header);

														/*phone = $(this).siblings().children('.phone').text();
                                    console.log(phone)*/
													});

													$(".btn-success").click(function() {

														var phone = $(this).siblings('#phone').val();

														var message = $(this).siblings('textarea').val();
														var test = "https://api.whatsapp.com/send?phone="+phone+"&text="+message;

														window.location.replace(test);
													})

												</script> 
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

					</div>	
					<div class="col-md-7">
						<h3><?php echo $hgo; ?></h3>
						<div class="services" style="visibility: visible;">
							<ul class="production">
								<li>Производство</li>
								<li><a>Россия</a></li>
								<li><a>Казахстан</a></li>
							</ul>
							<div>
								<a rel="nofollow">Арматура А3</a>
								<span class="length">Длина прута</span>
								<span class="ves-m">Вес метра</span>
								<span class="price-meter">Цена метра</span>
								<span class="price-tonn">Цена тонны</span>
								<span class="cart"><img src="./img/cart.svg" alt=""></span>
							</div>
							<?php foreach($armatura as $product) : ?>
							<div weight="<?php echo $product->weight ?>" pr_price="<?php echo $product->price_tonn ?>" pr_length="<?php echo $product->length ?>">
								<a rel="nofollow"><?php echo $product->diameter ?></a>
								<span class="length"><?php echo $product->length ?></span>
								<span class="ves-m"><?php echo $product->weight ?></span>
								<span class="price-meter"><?php echo $product->price_meter ?></span>
								<span class="price-tonn"><?php echo $product->price_tonn ?></span>
								<span class="cart"><img src="./img/cart.svg" alt=""></span>
							</div>
							<?php endforeach; ?>
						</div>
						<p></p>
					</div>

				</div>
			</div>
			<footer>
			</footer>

			<script src="./js/calculator.js"></script>
			<script src="./js/jqcart.js"></script>
			<script src="./js/my-script.js"></script>
		</body>
	</html>