<?php

	/*require '../bootstrap.php';*/

	$data = $_POST;

	print_r($data);

/*	$parent_table = $data['parent_table'];
	$table_id = $data['table_id'];
	$table_name = $data['table_name'];


	$table = R::findOne($parent_table, 'id = 2', [$table_id]);

	$table->$table_name = $data['value'];

	R::store($table);*/


?>