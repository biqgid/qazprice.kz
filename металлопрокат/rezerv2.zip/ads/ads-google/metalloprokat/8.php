<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'priceprokatalmmet'){$h1 = 'Прайс лист металлопроката в Алматы';}//-ЗАПРОС "priceprokatalmmet"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "priceprokatalmmet"
	if($_GET['h2'] == 'priceprokatalmmet'){$h2 = 'Лучшие цены на металлопрокат';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "priceprokatalmmet"
	if($_GET['h3'] == 'priceprokatalmmet'){$h3 = 'Узнать цены на металлопрокат в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "priceprokatalmmet"
	if($_GET['p'] == 'priceprokatalmmet'){$p = 'Актуальные цены на металлопрокат в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "priceprokatalmmet" == https://qazprice.kz/металлопрокат/металлопрокат/алматы?h1=priceprokatalmmet&h2=priceprokatalmmet&h3=priceprokatalmmet&p=priceprokatalmmet

//------------------------------------------------
?>