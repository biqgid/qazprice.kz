<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'prokatmetallalm'){$h1 = 'Металлопрокат в Алматы';}//-ЗАПРОС "prokatmetallalm"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "prokatmetallalm"
	if($_GET['h2'] == 'prokatmetallalm'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "prokatmetallalm"
	if($_GET['h3'] == 'prokatmetallalm'){$h3 = 'Узнать цены на металлопрокат в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "prokatmetallalm"
	if($_GET['p'] == 'prokatmetallalm'){$p = 'Актуальные цены на металлопрокат в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "prokatmetallalm" == https://qazprice.kz/металлопрокат/металлопрокат/алматы?h1=prokatmetallalm&h2=prokatmetallalm&h3=prokatmetallalm&p=prokatmetallalm

//------------------------------------------------
?>