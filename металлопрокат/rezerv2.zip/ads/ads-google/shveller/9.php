<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'shvelllercenazametralmatii'){$h1 = 'Швеллер цена за метр Алматы';}//-ЗАПРОС "shvelllercenazametralmatii"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "shvelllercenazametralmatii"
	if($_GET['h2'] == 'shvelllercenazametralmatii'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "shvelllercenazametralmatii"
	if($_GET['h3'] == 'shvelllercenazametralmatii'){$h3 = 'Узнать цены на стальной швеллер';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "shvelllercenazametralmatii"
	if($_GET['p'] == 'shvelllercenazametralmatii'){$p = 'Актуальные цены на швеллер в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "shvelllercenazametralmatii" == https://qazprice.kz/металлопрокат/швеллер/алматы?h1=shvelllercenazametralmatii&h2=shvelllercenazametralmatii&h3=shvelllercenazametralmatii&p=shvelllercenazametralmatii

//------------------------------------------------
?>