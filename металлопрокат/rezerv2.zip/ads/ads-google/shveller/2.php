<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'shvellerpricevalm'){$h1 = 'Прайс лист швеллер в Алматы';}//-ЗАПРОС "shvellerpricevalm"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "shvellerpricevalm"
	if($_GET['h2'] == 'shvellerpricevalm'){$h2 = 'Лучшие цены на стальной швеллер';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "shvellerpricevalm"
	if($_GET['h3'] == 'shvellerpricevalm'){$h3 = 'Узнать цены на стальной швеллер';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "shvellerpricevalm"
	if($_GET['p'] == 'shvellerpricevalm'){$p = 'Актуальные цены на стальной швеллер в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "shvellerpricevalm" == https://qazprice.kz/металлопрокат/швеллер/алматы?h1=shvellerpricevalm&h2=shvellerpricevalm&h3=shvellerpricevalm&p=shvellerpricevalm

//------------------------------------------------
?>