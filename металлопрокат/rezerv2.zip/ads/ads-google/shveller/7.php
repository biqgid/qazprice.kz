<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'byshvellerinalmati'){$h1 = 'Швеллер купить в Алматы';}//-ЗАПРОС "byshvellerinalmati"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "byshvellerinalmati"
	if($_GET['h2'] == 'byshvellerinalmati'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "byshvellerinalmati"
	if($_GET['h3'] == 'byshvellerinalmati'){$h3 = 'Узнать цены на стальной швеллер';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "byshvellerinalmati"
	if($_GET['p'] == 'byshvellerinalmati'){$p = 'Актуальные цены на швеллер в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "byshvellerinalmati" == https://qazprice.kz/металлопрокат/швеллер/алматы?h1=byshvellerinalmati&h2=byshvellerinalmati&h3=byshvellerinalmati&p=byshvellerinalmati

//------------------------------------------------
?>