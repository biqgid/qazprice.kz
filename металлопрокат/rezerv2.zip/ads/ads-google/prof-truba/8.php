<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'pricenaproftrubu'){$h1 = 'Прайс лист на профильную трубу';}//-ЗАПРОС "pricenaproftrubu"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "pricenaproftrubu"
	if($_GET['h2'] == 'pricenaproftrubu'){$h2 = 'Лучшие цены на профильные трубы';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "pricenaproftrubu"
	if($_GET['h3'] == 'pricenaproftrubu'){$h3 = 'Узнать цены на профильные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "pricenaproftrubu"
	if($_GET['p'] == 'pricenaproftrubu'){$p = 'Актуальные цены на профильные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "pricenaproftrubu" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=pricenaproftrubu&h2=pricenaproftrubu&h3=pricenaproftrubu&p=pricenaproftrubu

//------------------------------------------------
?>