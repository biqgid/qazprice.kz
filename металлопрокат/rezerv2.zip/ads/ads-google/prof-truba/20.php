<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubakvadrat80x80cenazametrvalm'){$h1 = 'Труба квадратная 80х80 цена за метр в Алматы';}//-ЗАПРОС "trubakvadrat80x80cenazametrvalm"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubakvadrat80x80cenazametrvalm"
	if($_GET['h2'] == 'trubakvadrat80x80cenazametrvalm'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubakvadrat80x80cenazametrvalm"
	if($_GET['h3'] == 'trubakvadrat80x80cenazametrvalm'){$h3 = 'Узнать цены на квадратные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubakvadrat80x80cenazametrvalm"
	if($_GET['p'] == 'trubakvadrat80x80cenazametrvalm'){$p = 'Актуальные цены на квадратные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubakvadrat80x80cenazametrvalm" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=trubakvadrat80x80cenazametrvalm&h2=trubakvadrat80x80cenazametrvalm&h3=trubakvadrat80x80cenazametrvalm&p=trubakvadrat80x80cenazametrvalm

//------------------------------------------------
?>