<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubakvadrat80x80cenaalm'){$h1 = 'Труба квадратная 80х80 цена';}//-ЗАПРОС "trubakvadrat80x80cenaalm"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubakvadrat80x80cenaalm"
	if($_GET['h2'] == 'trubakvadrat80x80cenaalm'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubakvadrat80x80cenaalm"
	if($_GET['h3'] == 'trubakvadrat80x80cenaalm'){$h3 = 'Узнать цены на квадратные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubakvadrat80x80cenaalm"
	if($_GET['p'] == 'trubakvadrat80x80cenaalm'){$p = 'Актуальные цены на квадратные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubakvadrat80x80cenaalm" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=trubakvadrat80x80cenaalm&h2=trubakvadrat80x80cenaalm&h3=trubakvadrat80x80cenaalm&p=trubakvadrat80x80cenaalm

//------------------------------------------------
?>