<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'kvadrattrubavalm'){$h1 = 'Квадратные трубы в Алматы';}//-ЗАПРОС "kvadrattrubavalm"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "kvadrattrubavalm"
	if($_GET['h2'] == 'kvadrattrubavalm'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "kvadrattrubavalm"
	if($_GET['h3'] == 'kvadrattrubavalm'){$h3 = 'Узнать цены на квадратные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "kvadrattrubavalm"
	if($_GET['p'] == 'kvadrattrubavalm'){$p = 'Актуальные цены на квадратные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "kvadrattrubavalm" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?kvadrattrubavalm=a3&kvadrattrubavalm=a3&kvadrattrubavalm=a3&p=kvadrattrubavalm

//------------------------------------------------
?>