<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'buyproftrubualm'){$h1 = 'Купить профильную трубу в Алматы';}//-ЗАПРОС "buyproftrubualm"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "buyproftrubualm"
	if($_GET['h2'] == 'buyproftrubualm'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "buyproftrubualm"
	if($_GET['h3'] == 'buyproftrubualm'){$h3 = 'Узнать цены на профильные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "buyproftrubualm"
	if($_GET['p'] == 'buyproftrubualm'){$p = 'Актуальные цены на профильные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "buyproftrubualm" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=buyproftrubualm&h2=buyproftrubualm&h3=buyproftrubualm&p=buyproftrubualm

//------------------------------------------------
?>