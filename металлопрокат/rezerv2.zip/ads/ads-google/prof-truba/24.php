<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubaprofilnaya40'){$h1 = 'Труба профильная 40';}//-ЗАПРОС "trubaprofilnaya40"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubaprofilnaya40"
	if($_GET['h2'] == 'trubaprofilnaya40'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubaprofilnaya40"
	if($_GET['h3'] == 'trubaprofilnaya40'){$h3 = 'Узнать цены на профильные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubaprofilnaya40"
	if($_GET['p'] == 'trubaprofilnaya40'){$p = 'Актуальные цены на профильные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubaprofilnaya40" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=trubaprofilnaya40&h2=trubaprofilnaya40&h3=trubaprofilnaya40&p=trubaprofilnaya40

//------------------------------------------------
?>