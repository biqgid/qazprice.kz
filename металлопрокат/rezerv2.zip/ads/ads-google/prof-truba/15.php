<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubakvadrat40x20cena'){$h1 = 'Труба квадратная 40х20 цена';}//-ЗАПРОС "trubakvadrat40x20cena"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubakvadrat40x20cena"
	if($_GET['h2'] == 'trubakvadrat40x20cena'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubakvadrat40x20cena"
	if($_GET['h3'] == 'trubakvadrat40x20cena'){$h3 = 'Узнать цены на квадратные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubakvadrat40x20cena"
	if($_GET['p'] == 'trubakvadrat40x20cena'){$p = 'Актуальные цены на квадратные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubakvadrat40x20cena" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=trubakvadrat40x20cena&h2=trubakvadrat40x20cena&h3=trubakvadrat40x20cena&p=trubakvadrat40x20cena

//------------------------------------------------
?>