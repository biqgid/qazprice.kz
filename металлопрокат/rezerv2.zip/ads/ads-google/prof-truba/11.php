<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'proftrubacenaalmm'){$h1 = 'Профильная труба цена Алматы';}//-ЗАПРОС "proftrubacenaalmm"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "proftrubacenaalmm"
	if($_GET['h2'] == 'proftrubacenaalmm'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "proftrubacenaalmm"
	if($_GET['h3'] == 'proftrubacenaalmm'){$h3 = 'Узнать цены на профильные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "proftrubacenaalmm"
	if($_GET['p'] == 'proftrubacenaalmm'){$p = 'Актуальные цены на профильные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "proftrubacenaalmm" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=proftrubacenaalmm&h2=proftrubacenaalmm&h3=proftrubacenaalmm&p=proftrubacenaalmm

//------------------------------------------------
?>