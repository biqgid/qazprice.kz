<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'kvadrattrubacena'){$h1 = 'Квадрат труба цена';}//-ЗАПРОС "kvadrattrubacena"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "kvadrattrubacena"
	if($_GET['h2'] == 'kvadrattrubacena'){$h2 = 'Прайс лист на квадратные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "kvadrattrubacena"
	if($_GET['h3'] == 'kvadrattrubacena'){$h3 = 'Квадратные трубы всех марок стали';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "kvadrattrubacena"
	if($_GET['p'] == 'kvadrattrubacena'){$p = 'Квадратные трубы всех диаметров в наличии и под заказ в Алматы, актуальные цены, скидки!';}
}

//-на запрос "kvadrattrubacena" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=kvadrattrubacena&h2=kvadrattrubacena&h3=kvadrattrubacena&p=kvadrattrubacena

//------------------------------------------------
?>