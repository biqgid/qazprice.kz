<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubaprofilnayavalmatii'){$h1 = 'Труба профильная в Алматы';}//-ЗАПРОС "trubaprofilnayavalmatii"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubaprofilnayavalmatii"
	if($_GET['h2'] == 'trubaprofilnayavalmatii'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubaprofilnayavalmatii"
	if($_GET['h3'] == 'trubaprofilnayavalmatii'){$h3 = 'Узнать цены на профильные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubaprofilnayavalmatii"
	if($_GET['p'] == 'trubaprofilnayavalmatii'){$p = 'Актуальные цены на профильные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubaprofilnayavalmatii" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=trubaprofilnayavalmatii&h2=trubaprofilnayavalmatii&h3=trubaprofilnayavalmatii&p=trubaprofilnayavalmatii

//------------------------------------------------
?>