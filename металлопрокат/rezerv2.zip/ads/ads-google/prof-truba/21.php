<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubakvadrataalmm'){$h1 = 'Труба квадратная Алматы';}//-ЗАПРОС "trubakvadrataalmm"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubakvadrataalmm"
	if($_GET['h2'] == 'trubakvadrataalmm'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubakvadrataalmm"
	if($_GET['h3'] == 'trubakvadrataalmm'){$h3 = 'Узнать цены на квадратные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubakvadrataalmm"
	if($_GET['p'] == 'trubakvadrataalmm'){$p = 'Актуальные цены на квадратные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubakvadrataalmm" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=trubakvadrataalmm&h2=trubakvadrataalmm&h3=trubakvadrataalmm&p=trubakvadrataalmm

//------------------------------------------------
?>