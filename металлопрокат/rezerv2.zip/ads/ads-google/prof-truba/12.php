<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'proftrubacenametra'){$h1 = 'Профильная труба цена за метр';}//-ЗАПРОС "proftrubacenametra"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "proftrubacenametra"
	if($_GET['h2'] == 'proftrubacenametra'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "proftrubacenametra"
	if($_GET['h3'] == 'proftrubacenametra'){$h3 = 'Узнать цены на профильные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "proftrubacenametra"
	if($_GET['p'] == 'proftrubacenametra'){$p = 'Актуальные цены на профильные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "proftrubacenametra" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=proftrubacenametra&h2=proftrubacenametra&h3=proftrubacenametra&p=proftrubacenametra

//------------------------------------------------
?>