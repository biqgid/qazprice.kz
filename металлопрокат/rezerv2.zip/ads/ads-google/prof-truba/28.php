<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'cenanaprofilnuyutrubu'){$h1 = 'Цена на профильные трубы';}//-ЗАПРОС "cenanaprofilnuyutrubu"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "cenanaprofilnuyutrubu"
	if($_GET['h2'] == 'cenanaprofilnuyutrubu'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "cenanaprofilnuyutrubu"
	if($_GET['h3'] == 'cenanaprofilnuyutrubu'){$h3 = 'Узнать цены на профильные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "cenanaprofilnuyutrubu"
	if($_GET['p'] == 'cenanaprofilnuyutrubu'){$p = 'Актуальные цены на профильные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "cenanaprofilnuyutrubu" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=cenanaprofilnuyutrubu&h2=cenanaprofilnuyutrubu&h3=cenanaprofilnuyutrubu&p=cenanaprofilnuyutrubu

//------------------------------------------------
?>