<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubaprofilnayacenazametrr'){$h1 = 'Труба профильная цена за метр в Алматы';}//-ЗАПРОС "trubaprofilnayacenazametrr"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubaprofilnayacenazametrr"
	if($_GET['h2'] == 'trubaprofilnayacenazametrr'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubaprofilnayacenazametrr"
	if($_GET['h3'] == 'trubaprofilnayacenazametrr'){$h3 = 'Узнать цены на профильные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubaprofilnayacenazametrr"
	if($_GET['p'] == 'trubaprofilnayacenazametrr'){$p = 'Актуальные цены на профильные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubaprofilnayavalmatiicena" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=trubaprofilnayacenazametrr&h2=trubaprofilnayacenazametrr&h3=trubaprofilnayacenazametrr&p=trubaprofilnayacenazametrr

//------------------------------------------------
?>