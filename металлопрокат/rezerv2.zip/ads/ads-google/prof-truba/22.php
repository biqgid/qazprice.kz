<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubakvadratvaalmm'){$h1 = 'Труба квадратная в Алматы';}//-ЗАПРОС "trubakvadratvaalmm"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubakvadratvaalmm"
	if($_GET['h2'] == 'trubakvadratvaalmm'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubakvadratvaalmm"
	if($_GET['h3'] == 'trubakvadratvaalmm'){$h3 = 'Узнать цены на квадратные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubakvadratvaalmm"
	if($_GET['p'] == 'trubakvadratvaalmm'){$p = 'Актуальные цены на квадратные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubakvadratvaalmm" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=trubakvadratvaalmm&h2=trubakvadratvaalmm&h3=trubakvadratvaalmm&p=trubakvadratvaalmm

//------------------------------------------------
?>