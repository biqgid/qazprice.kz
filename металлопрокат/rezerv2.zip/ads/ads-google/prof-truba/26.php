<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubaprofilnayavalmatiicena'){$h1 = 'Труба профильная Алматы цена';}//-ЗАПРОС "trubaprofilnayavalmatiicena"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubaprofilnayavalmatiicena"
	if($_GET['h2'] == 'trubaprofilnayavalmatiicena'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubaprofilnayavalmatiicena"
	if($_GET['h3'] == 'trubaprofilnayavalmatiicena'){$h3 = 'Узнать цены на профильные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubaprofilnayavalmatiicena"
	if($_GET['p'] == 'trubaprofilnayavalmatiicena'){$p = 'Актуальные цены на профильные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubaprofilnayavalmatiicena" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=trubaprofilnayavalmatiicena&h2=trubaprofilnayavalmatiicena&h3=trubaprofilnayavalmatiicena&p=trubaprofilnayavalmatiicena

//------------------------------------------------
?>