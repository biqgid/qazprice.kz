<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubakvadratnaya'){$h1 = 'Труба квадратная';}//-ЗАПРОС "trubakvadratnaya"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubakvadratnaya"
	if($_GET['h2'] == 'trubakvadratnaya'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubakvadratnaya"
	if($_GET['h3'] == 'trubakvadratnaya'){$h3 = 'Узнать цены на квадратные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubakvadratnaya"
	if($_GET['p'] == 'trubakvadratnaya'){$p = 'Актуальные цены на квадратные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubakvadratnaya" == https://qazprice.kz/металлопрокат/профильные-трубы/алматы?h1=trubakvadratnaya&h2=trubakvadratnaya&h3=trubakvadratnaya&p=trubakvadratnaya

//------------------------------------------------
?>