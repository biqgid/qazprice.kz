<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'shestigrannikhotstall'){$h1 = 'Шестигранник стальной горячекатаный';}//-ЗАПРОС "shestigrannikhotstall"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "shestigrannikhotstall"
	if($_GET['h2'] == 'shestigrannikhotstall'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "shestigrannikhotstall"
	if($_GET['h3'] == 'shestigrannikhotstall'){$h3 = 'Узнать цены на стальной шестигранник';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "shestigrannikhotstall"
	if($_GET['p'] == 'shestigrannikhotstall'){$p = 'Актуальные цены на стальной шестигранник в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "shestigrannikhotstall" == https://qazprice.kz/металлопрокат/шестигранник/алматы?h1=shestigrannikhotstall&h2=shestigrannikhotstall&h3=shestigrannikhotstall&p=shestigrannikhotstall

//------------------------------------------------
?>