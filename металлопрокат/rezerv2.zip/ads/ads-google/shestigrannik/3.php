<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'shestigrannikstallby'){$h1 = 'Купить шестигранник стальной';}//-ЗАПРОС "shestigrannikstallby"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "shestigrannikstallby"
	if($_GET['h2'] == 'shestigrannikstallby'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "shestigrannikstallby"
	if($_GET['h3'] == 'shestigrannikstallby'){$h3 = 'Узнать цены на стальной шестигранник';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "shestigrannikstallby"
	if($_GET['p'] == 'shestigrannikstallby'){$p = 'Актуальные цены на стальной шестигранник в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "shestigrannikstallby" == https://qazprice.kz/металлопрокат/шестигранник/алматы?h1=shestigrannikstallby&h2=shestigrannikstallby&h3=shestigrannikstallby&p=shestigrannikstallby

//------------------------------------------------
?>