<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'shestigrannikstallprokat5m5m'){$h1 = 'Шестигранник стальной прокат 5 5 мм';}//-ЗАПРОС "shestigrannikstallprokat5m5m"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "shestigrannikstallprokat5m5m"
	if($_GET['h2'] == 'shestigrannikstallprokat5m5m'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "shestigrannikstallprokat5m5m"
	if($_GET['h3'] == 'shestigrannikstallprokat5m5m'){$h3 = 'Узнать цены на стальной шестигранник';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "shestigrannikstallprokat5m5m"
	if($_GET['p'] == 'shestigrannikstallprokat5m5m'){$p = 'Актуальные цены на стальной шестигранник в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "shestigrannikstallprokat5m5m" == https://qazprice.kz/металлопрокат/шестигранник/алматы?h1=shestigrannikstallprokat5m5m&h2=shestigrannikstallprokat5m5m&h3=shestigrannikstallprokat5m5m&p=shestigrannikstallprokat5m5m

//------------------------------------------------
?>