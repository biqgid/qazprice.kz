<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'shestigrannikcenazametr'){$h1 = 'Шестигранник цена за метр';}//-ЗАПРОС "shestigrannikcenazametr
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "shestigrannikcenazametr"
	if($_GET['h2'] == 'shestigrannikcenazametr'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "shestigrannikcenazametr"
	if($_GET['h3'] == 'shestigrannikcenazametr'){$h3 = 'Узнать цены на стальной шестигранник';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "shestigrannikcenazametr"
	if($_GET['p'] == 'shestigrannikcenazametr'){$p = 'Актуальные цены на стальной шестигранник в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "shestigrannikcenazametr" == https://qazprice.kz/металлопрокат/шестигранник/алматы?h1=shestigrannikcenazametr&h2=shestigrannikcenazametr&h3=shestigrannikcenazametr&p=shestigrannikcenazametr

//------------------------------------------------
?>