<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'shestigrannikby'){$h1 = 'Купить шестигранник';}//-ЗАПРОС "shestigrannikby"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "shestigrannikby"
	if($_GET['h2'] == 'shestigrannikby'){$h2 = 'Лучшие цены на шестигранник';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "shestigrannikby"
	if($_GET['h3'] == 'shestigrannikby'){$h3 = 'Узнать цены на стальной шестигранник';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "shestigrannikby"
	if($_GET['p'] == 'shestigrannikby'){$p = 'Актуальные цены на стальной шестигранник в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "shestigrannikby" == https://qazprice.kz/металлопрокат/шестигранник/алматы?h1=shestigrannikby&h2=shestigrannikby&h3=shestigrannikby&p=shestigrannikby

//------------------------------------------------
?>