<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'okpd2shestigrannik'){$h1 = 'Окпд 2 шестигранник стальной';}//-ЗАПРОС "okpd2shestigrannik"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "okpd2shestigrannik"
	if($_GET['h2'] == 'okpd2shestigrannik'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "okpd2shestigrannik"
	if($_GET['h3'] == 'okpd2shestigrannik'){$h3 = 'Узнать цены на стальной шестигранник';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "okpd2shestigrannik"
	if($_GET['p'] == 'okpd2shestigrannik'){$p = 'Актуальные цены на стальной шестигранник в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "okpd2shestigrannik" == https://qazprice.kz/металлопрокат/шестигранник/алматы?h1=okpd2shestigrannik&h2=okpd2shestigrannik&h3=okpd2shestigrannik&p=okpd2shestigrannik

//------------------------------------------------
?>