<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'listcenamaalmatii'){$h1 = 'Металлический лист цена Алматы';}//-ЗАПРОС "listcenamaalmatii"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "listcenamaalmatii"
	if($_GET['h2'] == 'listcenamaalmatii'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "listcenamaalmatii"
	if($_GET['h3'] == 'listcenamaalmatii'){$h3 = 'Узнать цены на металл листы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "listcenamaalmatii"
	if($_GET['p'] == 'listcenamaalmatii'){$p = 'Актуальные цены на металлические листы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "listcenamaalmatii" == https://qazprice.kz/металлопрокат/арматура/алматы?h1=listcenamaalmatii&h2=listcenamaalmatii&h3=listcenamaalmatii&p=listcenamaalmatii

//------------------------------------------------
?>