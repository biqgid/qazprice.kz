<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'ugolokmetallicheskiycenazametralmati'){$h1 = 'Уголок металлический цена за метр Алматы';}//-ЗАПРОС "ugolokmetallicheskiycenazametralmati"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "ugolokmetallicheskiycenazametralmati"
	if($_GET['h2'] == 'ugolokmetallicheskiycenazametralmati'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "ugolokmetallicheskiycenazametralmati"
	if($_GET['h3'] == 'ugolokmetallicheskiycenazametralmati'){$h3 = 'Узнать цены на металлические уголки';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "ugolokmetallicheskiycenazametralmati"
	if($_GET['p'] == 'ugolokmetallicheskiycenazametralmati'){$p = 'Актуальные цены на металлические уголки в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "ugolokmetallicheskiycenazametralmati" == https://qazprice.kz/металлопрокат/уголок/алматы?h1=ugolokmetallicheskiycenazametralmati&h2=ugolokmetallicheskiycenazametralmati&h3=ugolokmetallicheskiycenazametralmati&p=ugolokmetallicheskiycenazametralmati

//------------------------------------------------
?>