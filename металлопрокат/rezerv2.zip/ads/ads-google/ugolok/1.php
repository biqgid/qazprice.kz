<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'stalugolok50x50cenazametr'){$h1 = 'Уголок 50х50 цена за метр в Алматы';}//-ЗАПРОС "stalugolok50x50cenazametr"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "stalugolok50x50cenazametr"
	if($_GET['h2'] == 'stalugolok50x50cenazametr'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "stalugolok50x50cenazametr"
	if($_GET['h3'] == 'stalugolok50x50cenazametr'){$h3 = 'Узнать цены на стальные уголки';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "stalugolok50x50cenazametr"
	if($_GET['p'] == 'stalugolok50x50cenazametr'){$p = 'Актуальные цены на стальные уголки в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "stalugolok50x50cenazametr" == https://qazprice.kz/металлопрокат/уголок/алматы?h1=stalugolok50x50cenazametr&h2=stalugolok50x50cenazametr&h3=stalugolok50x50cenazametr&p=stalugolok50x50cenazametr

//------------------------------------------------
?>