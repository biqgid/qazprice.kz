<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'ugolokmetallalmati'){$h1 = 'Уголок металлический Алматы';}//-ЗАПРОС "ugolokmetallalmati"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "ugolokmetallalmati"
	if($_GET['h2'] == 'ugolokmetallalmati'){$h2 = 'Лучшие цены на металлические уголки';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "ugolokmetallalmati"
	if($_GET['h3'] == 'ugolokmetallalmati'){$h3 = 'Узнать цены на металлические уголки';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "ugolokmetallalmati"
	if($_GET['p'] == 'ugolokmetallalmati'){$p = 'Актуальные цены на металлические уголки в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "ugolokmetallalmati" == https://qazprice.kz/металлопрокат/уголок/алматы?h1=ugolokmetallalmati&h2=ugolokmetallalmati&h3=ugolokmetallalmati&p=ugolokmetallalmati
//------------------------------------------------
?>