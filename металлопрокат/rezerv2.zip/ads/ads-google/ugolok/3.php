<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'ugolokmetallicheskiycena'){$h1 = 'Уголок металлический цена Алматы';}//-ЗАПРОС "ugolokmetallicheskiycena"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "ugolokmetallicheskiycena"
	if($_GET['h2'] == 'ugolokmetallicheskiycena'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "ugolokmetallicheskiycena"
	if($_GET['h3'] == 'ugolokmetallicheskiycena'){$h3 = 'Узнать цены на металлические уголки';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "ugolokmetallicheskiycena"
	if($_GET['p'] == 'ugolokmetallicheskiycena'){$p = 'Актуальные цены на металлические уголки в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "ugolokmetallicheskiycena" == https://qazprice.kz/металлопрокат/уголок/алматы?h1=ugolokmetallicheskiycena&h2=ugolokmetallicheskiycena&h3=ugolokmetallicheskiycena&p=ugolokmetallicheskiycena

//------------------------------------------------
?>