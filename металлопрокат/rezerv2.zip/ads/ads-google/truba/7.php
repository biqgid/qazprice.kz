<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubastallcenaa'){$h1 = 'Труба стальная цена';}//-ЗАПРОС "trubastallcenaa"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubastallcenaa"
	if($_GET['h2'] == 'trubastallcenaa'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubastallcenaa"
	if($_GET['h3'] == 'trubastallcenaa'){$h3 = 'Узнать цены на стальные трубы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubastallcenaa"
	if($_GET['p'] == 'trubastallcenaa'){$p = 'Актуальные цены на стальные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubastallcenaa" == https://qazprice.kz/металлопрокат/трубы/алматы?h1=trubastallcenaa&h2=trubastallcenaa&h3=trubastallcenaa&p=trubastallcenaa

//------------------------------------------------
?>