<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'buytrubuvalmati'){$h1 = 'Купить трубу в Алматы';}//-ЗАПРОС "buytrubuvalmati"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "buytrubuvalmati"
	if($_GET['h2'] == 'buytrubuvalmati'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "buytrubuvalmati"
	if($_GET['h3'] == 'buytrubuvalmati'){$h3 = 'Узнать цены на стальные трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "buytrubuvalmati"
	if($_GET['p'] == 'buytrubuvalmati'){$p = 'Актуальные цены на стальные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "buytrubuvalmati" == https://qazprice.kz/металлопрокат/трубы/алматы?h1=buytrubuvalmati&h2=buytrubuvalmati&h3=buytrubuvalmati&p=buytrubuvalmati

//------------------------------------------------
?>