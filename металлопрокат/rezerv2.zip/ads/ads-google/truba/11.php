<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubistallprice'){$h1 = 'Трубы стальные прайс';}//-ЗАПРОС "trubistallprice"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubistallprice"
	if($_GET['h2'] == 'trubistallprice'){$h2 = 'Прайс лист на стальные трубы';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubistallprice"
	if($_GET['h3'] == 'trubistallprice'){$h3 = 'Узнать цены на стальные трубы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubistallprice"
	if($_GET['p'] == 'trubistallprice'){$p = 'Актуальные цены на стальные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubistallprice" == https://qazprice.kz/металлопрокат/трубы/алматы?h1=trubistallprice&h2=trubistallprice&h3=trubistallprice&p=trubistallprice

//------------------------------------------------
?>