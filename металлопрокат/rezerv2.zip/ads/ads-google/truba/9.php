<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubimetallvalmatii'){$h1 = 'Трубы металлические в Алматы';}//-ЗАПРОС "trubimetallvalmatii"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubimetallvalmatii"
	if($_GET['h2'] == 'trubimetallvalmatii'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubimetallvalmatii"
	if($_GET['h3'] == 'trubimetallvalmatii'){$h3 = 'Узнать цены на металлические трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubimetallvalmatii"
	if($_GET['p'] == 'trubimetallvalmatii'){$p = 'Актуальные цены на металлические трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubimetallvalmatii" == https://qazprice.kz/металлопрокат/трубы/алматы?h1=trubimetallvalmatii&h2=trubimetallvalmatii&h3=trubimetallvalmatii&p=trubimetallvalmatii

//------------------------------------------------
?>