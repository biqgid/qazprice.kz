<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubiimetallicheskiye'){$h1 = 'Трубы металлические';}//-ЗАПРОС "trubiimetallicheskiye"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubametallicheskaya"
	if($_GET['h2'] == 'trubiimetallicheskiye'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubametallicheskaya"
	if($_GET['h3'] == 'trubiimetallicheskiye'){$h3 = 'Узнать цены на металлические трубы в Алматы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubametallicheskaya"
	if($_GET['p'] == 'trubiimetallicheskiye'){$p = 'Актуальные цены на металлические трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubiimetallicheskiye" == https://qazprice.kz/металлопрокат/трубы/алматы?h1=trubiimetallicheskiye&h2=trubiimetallicheskiye&h3=trubiimetallicheskiye&p=trubiimetallicheskiye

//------------------------------------------------
?>