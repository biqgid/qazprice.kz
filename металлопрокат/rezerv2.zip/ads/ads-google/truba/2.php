<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'buytrubiivalmati'){$h1 = 'Купить трубы в алматы';}//-ЗАПРОС "buytrubiivalmati"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "buytrubiivalmati"
	if($_GET['h2'] == 'buytrubiivalmati'){$h2 = 'Лучшие цены на стальные трубы';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "buytrubiivalmati"
	if($_GET['h3'] == 'buytrubiivalmati'){$h3 = 'Узнать цены на стальные трубы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "buytrubiivalmati"
	if($_GET['p'] == 'buytrubiivalmati'){$p = 'Актуальные цены на стальные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "buytrubiivalmati" == https://qazprice.kz/металлопрокат/трубы/алматы?h1=buytrubiivalmati&h2=buytrubiivalmati&h3=buytrubiivalmati&p=buytrubiivalmati

//------------------------------------------------
?>