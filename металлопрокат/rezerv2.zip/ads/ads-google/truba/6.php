<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubametallicheskaya'){$h1 = 'Труба металлическая';}//-ЗАПРОС "trubametallicheskaya"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubametallicheskaya"
	if($_GET['h2'] == 'trubametallicheskaya'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubametallicheskaya"
	if($_GET['h3'] == 'trubametallicheskaya'){$h3 = 'Узнать цены на металлические трубы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubametallicheskaya"
	if($_GET['p'] == 'trubametallicheskaya'){$p = 'Актуальные цены на металлические трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubametallicheskaya" == https://qazprice.kz/металлопрокат/трубы/алматы?h1=trubametallicheskaya&h2=trubametallicheskaya&h3=trubametallicheskaya&p=trubametallicheskaya

//------------------------------------------------
?>