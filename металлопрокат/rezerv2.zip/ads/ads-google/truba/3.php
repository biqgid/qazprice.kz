<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'metalltrubyalmati'){$h1 = 'Металлические трубы Алматы';}//-ЗАПРОС "metalltrubyalmati"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "metalltrubyalmati"
	if($_GET['h2'] == 'metalltrubyalmati'){$h2 = 'Прайс лист с ценами';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "metalltrubyalmati"
	if($_GET['h3'] == 'metalltrubyalmati'){$h3 = 'Узнать цены на металлические трубы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "metalltrubyalmati"
	if($_GET['p'] == 'metalltrubyalmati'){$p = 'Актуальные цены на металлические трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "metalltrubyalmati" == https://qazprice.kz/металлопрокат/трубы/алматы?h1=metalltrubyalmati&h2=metalltrubyalmati&h3=metalltrubyalmati&p=metalltrubyalmati

//------------------------------------------------
?>