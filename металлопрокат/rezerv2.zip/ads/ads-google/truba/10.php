<?php 
//------------------------------------------------
if(isset($_GET['h1'])){
	if($_GET['h1'] == 'trubiistallalmatii'){$h1 = 'Трубы стальные Алматы';}//-ЗАПРОС "trubiistallalmatii"
}
//------------------------------------------------
if(isset($_GET['h2'])){//-на запрос "trubistallalmatii"
	if($_GET['h2'] == 'trubiistallalmatii'){$h2 = 'Прайс лист на стальные трубы';}
}
//------------------------------------------------
if(isset($_GET['h3'])){//-на запрос "trubistallalmatii"
	if($_GET['h3'] == 'trubiistallalmatii'){$h3 = 'Узнать цены на стальные трубы';}
}
//------------------------------------------------
if(isset($_GET['p'])){//-на запрос "trubastallcenaa"
	if($_GET['p'] == 'trubiistallalmatii'){$p = 'Актуальные цены на стальные трубы в городе Алматы, скидки! Заказать онлайн на сайте';}
}

//-на запрос "trubiistallalmatii" == https://qazprice.kz/металлопрокат/трубы/алматы?h1=trubiistallalmatii&h2=trubiistallalmatii&h3=trubiistallalmatii&p=trubiistallalmatii

//------------------------------------------------
?>