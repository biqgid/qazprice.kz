<p class="p">Форма заявки</p>
						<div class="line-separator5"></div>
						<p>Для получения индивидуального коммерческое предложения заполните форму</p>
						<div class="margin-top70">
							<form id="form" method="post">
								<div class="row">
									<div class="col-md-6 required">
										<input type="text" name="name" placeholder="Введите Ваше Имя" required> </div>
									<div class="col-md-6 required">
										<input type="text" name="email" placeholder="Введите Ваш e-mail" required>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12 required">
										<input type="text" name="phone" placeholder="Введите Ваш телефон" required>
									</div>
								</div>
								<div class="row">
									<div class="col-md-12 col-xs-12 required">
										<textarea rows="10" cols="45" name="message" required placeholder="Введите Вашу заявку"></textarea>
									</div>
									<div class="col-md-12 col-xs-12 text-center">
										<br>
										<div class="g-recaptcha" data-sitekey="6LdSplwUAAAAAIZFBi85M3_FNYnqa2ByjilibCEy"></div>
										<br>
										<input type="submit" name="submit-contact" value="Отправить">
									</div>
								</div>
							</form>
						</div>

