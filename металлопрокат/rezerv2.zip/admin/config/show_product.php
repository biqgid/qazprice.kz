<?php
	require 'config/DB.php';

	$categories = R::findAll('product');

?>