<?php
	require "auth.php";
?>

<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="content-language" content="ru-ru">
    <title>Прайс-лист</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/admin_page.css">

    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

    <script type="text/javascript">
        var doc = new jsPDF();
		var specialElementHandlers = {
		    '#editor': function (element, renderer) {
		        return true;
		    }
		};

		$('#cmd').click(function () {
		    doc.fromHTML($('#content').html(), 15, 15, {
		        'width': 170,
		            'elementHandlers': specialElementHandlers
		    });
		    doc.save('sample-file.pdf');
		});
    </script>
</head>

<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
		<ul class="nav nav-pills">
		  <li class="nav-item">
		    <a class="nav-link active" href="/">Главная</a>
		  </li>
		  <li class="nav-item dropdown">
		    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Пункт</a>
		    <div class="dropdown-menu">
		      <a class="dropdown-item" href="#">Action</a>
		      <a class="dropdown-item" href="#">Another action</a>
		      <a class="dropdown-item" href="#">Something else here</a>
		      <div class="dropdown-divider"></div>
		      <a class="dropdown-item" href="#">Separated link</a>
		    </div>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" href="#">Link</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link disabled" href="admin.php?do=logout">Выйти</a>
		  </li>
		</ul>
	</nav>
	<div id="content">
		<table>
			<tr>
			  	<th>
				  	<img src="img/logo.png"> 
				  	<br>
				  	<br>
				  	ТОО "IRON COMMERCE COMPANY"
			  	</th>
			  	<th>
			  		Офис/База: п.Боралдай, ул. Бережинского, 17<br>
					ОПТОВЫЕ ПРОДАЖИ: моб.: 8 700 341 04 04<br>
					marya_iron@mail.ru<br>			
					www.ironcc.kz<br>
					11.07.2018г.
			 	</th>
			  	<th>
			  		п.Боралдай	
					8-747-341-04-04	
					8(727) 341-04-04	
					8(727) 371-19-09	
					8(727) 371-19-20
					<br>
					ул.Рыскулова 61Г
			    	8(727)294-20-73
			    	8(727)294-20-96
			    	8(727)294-20-69
			    	<br>
			    	Кокорай 32
			    	8(727)395-38-85
					8(727)395-38-86
				</th>
			<tr>
		</table>

		<table>
		   <caption>АРМАТУРА АIII ГОСТ 5781-82</caption>
		   <tr>
		      <th rowspan="2" class="first">Диаметр, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина, м.</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>8 (тянутая)</td>
		      <td>0,4
		      <td>6,15</td>
		      <td>88</td>
		      <td>215000</td>
		      <td>Россия</td>
		      <td>2,46</td>
		   </tr>
		   <tr>
		      <td>10 (A500/35ГС)</td>
		      <td>0,62
		      <td>11,75</td>
		      <td>135,3</td>
		      <td>215000</td>
		      <td>Россия</td>
		      <td>7,285</td>
		   </tr>
		   <tr>
		      <td>12 (A500/35ГС)</td>
		      <td>0,92
		      <td>11,75</td>
		      <td>194,28</td>
		      <td>209000</td>
		      <td>Россия</td>
		      <td>10,81</td>
		   </tr>
		   <tr>
		      <td>14 (A500/35ГС)</td>
		      <td>1,23
		      <td>11,75</td>
		      <td>254,15</td>
		      <td>205000</td>
		      <td>Россия</td>
		      <td>14,4525</td>
		   </tr>
		   <tr>
		      <td>16 (A500/35ГС)</td>
		      <td>1,66
		      <td>11,75</td>
		      <td>342,3</td>
		      <td>205000</td>
		      <td>Россия</td>
		      <td>19,505</td>
		   </tr>
		   <tr>
		      <td>18 (A500/35ГС)</td>
		      <td>1,95
		      <td>11,75</td>
		      <td>401,75</td>
		      <td>205000</td>
		      <td>Россия</td>
		      <td>22,9125</td>
		   </tr>
		   <tr>
		      <td>20 (A500/35ГС)</td>
		      <td>2,65
		      <td>11,75</td>
		      <td>545,25</td>
		      <td>205000</td>
		      <td>Россия</td>
		      <td>31,1375</td>
		   </tr>
		   <tr>
		      <td>22 (A500/35ГС)</td>
		      <td>2,75
		      <td>11,75</td>
		      <td>565,75</td>
		      <td>205000</td>
		      <td>Россия</td>
		      <td>32,3125</td>
		   </tr>
		   <tr>
		      <td>25 (A500/35ГС)</td>
		      <td>3,92
		      <td>12</td>
		      <td>805,6</td>
		      <td>205000</td>
		      <td>Россия</td>
		      <td>47,04</td>
		   </tr>
		   <tr>
		      <td>28 (A500/35ГС)</td>
		      <td>4,83
		      <td>11,75</td>
		      <td>992,15</td>
		      <td>205000</td>
		      <td>Россия</td>
		      <td>56,7525</td>
		   </tr>
		   <tr>
		      <td>32 (A500/35ГС)</td>
		      <td>6,4
		      <td>11,75</td>
		      <td>1314</td>
		      <td>205000</td>
		      <td>Россия</td>
		      <td>75,2</td>
		   </tr>
		   <tr>
		      <td>36 (А500)</td>
		      <td>7,99
		      <td>11,75</td>
		      <td>1639,95</td>
		      <td>205000</td>
		      <td>Россия</td>
		      <td>93,8825</td>
		   </tr>
		</table>
		<table>
		   <caption>АРМАТУРА АIII Казахстан</caption>
		   <tr>
		      <th rowspan="2" class="first">Диаметр, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина, м.</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>10</td>
		      <td>0,63
		      <td>6</td>
		      <td>118,55</td>
		      <td>185000</td>
		      <td>Казахстан</td>
		      <td>3,78</td>
		   </tr>
		   <tr>
		      <td>12</td>
		      <td>0,65
		      <td>6</td>
		      <td>122,25</td>
		      <td>185000</td>
		      <td>Казахстан</td>
		      <td>3,9</td>
		   </tr>
		   <tr>
		      <td>12</td>
		      <td>0,8
		      <td>6</td>
		      <td>142</td>
		      <td>175000</td>
		      <td>Казахстан</td>
		      <td>4,8</td>
		   </tr>
		   <tr>
		      <td>12</td>
		      <td>0,8
		      <td>11,75</td>
		      <td>150</td>
		      <td>185000</td>
		      <td>Казахстан</td>
		      <td>9,4</td>
		   </tr>
		   <tr>
		      <td>12</td>
		      <td>0,93
		      <td>11,75</td>
		      <td>174,05</td>
		      <td>185000</td>
		      <td>Казахстан</td>
		      <td>10,93</td>
		   </tr>
		   <tr>
		      <td>14</td>
		      <td>1,23
		      <td>11,75</td>
		      <td>211,1</td>
		      <td>170000</td>
		      <td>Казахстан</td>
		      <td>14,45</td>
		   </tr>
		   <tr>
		      <td>16</td>
		      <td>1,58
		      <td>6/11,75</td>
		      <td>294,3</td>
		      <td>185000</td>
		      <td>Казахстан</td>
		      <td>9,48/18,56</td>
		   </tr>
		</table>
		<table>
		   <caption>КАТАНКА ГОСТ 5282-94</caption>
		   <tr>
		      <th rowspan="2" class="first">Диаметр, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина, м.</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>6,5 (бунт)</td>
		      <td>0,85
		      <td></td>
		      <td></td>
		      <td>214000</td>
		      <td>Россия</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>6,5 (тянутая)</td>
		      <td>0,28
		      <td>6,15</td>
		      <td>63,32</td>
		      <td>219000</td>
		      <td>Россия</td>
		      <td>1,722</td>
		   </tr>
		   <tr>
		      <td>8 (бунт)</td>
		      <td>0,85
		      <td></td>
		      <td></td>
		      <td>214000</td>
		      <td>Россия</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>8 (тянутая)</td>
		      <td>0,395
		      <td>6,15</td>
		      <td>88,505</td>
		      <td>219000</td>
		      <td>Россия</td>
		      <td>2,42925</td>
		   </tr>
		</table>
		<table>
		   <caption>КРУГ</caption>
		   <tr>
		      <th rowspan="2" class="first">Диаметр, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина, м.</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>10</td>
		      <td>0,64
		      <td>6/11,75</td>
		      <td>143,44</td>
		      <td>221000</td>
		      <td>Казахстан/Россия</td>
		      <td>3,84/7,52</td>
		   </tr>
		   <tr>
		      <td>12</td>
		      <td>0,93
		      <td>11,75/12</td>
		      <td>204,74</td>
		      <td>218000</td>
		      <td>Казахстан/Россия</td>
		      <td>10,93/11,16</td>
		   </tr>
		   <tr>
		      <td>14</td>
		      <td>1,21
		      <td>6/12</td>
		      <td>263,36</td>
		      <td>216000</td>
		      <td>Казахстан/Россия</td>
		      <td>7,26/14,52</td>
		   </tr>
		   <tr>
		      <td>16</td>
		      <td>1,58
		      <td>6/12</td>
		      <td>343,28</td>
		      <td>216000</td>
		      <td>Казахстан/Россия</td>
		      <td>9,48/18,96</td>
		   </tr>
		</table>
		<table>
		   <caption>КВАДРАТ </caption>
		   <tr>
		      <th rowspan="2" class="first">Диаметр, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина, м.</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>10</td>
		      <td>0,86
		      <td>6</td>
		      <td>165,4</td>
		      <td>190000</td>
		      <td>Киргизия</td>
		      <td>5,16</td>
		   </tr>
		   <tr>
		      <td>12</td>
		      <td>1,31
		      <td>6</td>
		      <td>250,9</td>
		      <td>190000</td>
		      <td>Киргизия</td>
		      <td>7,86</td>
		   </tr>
		   <tr>
		      <td>14</td>
		      <td>1,54
		      <td>6</td>
		      <td>294,6</td>
		      <td>190000</td>
		      <td>Киргизия</td>
		      <td>9,24</td>
		   </tr>
		   <tr>
		      <td>16</td>
		      <td>2,01
		      <td>6</td>
		      <td>383,9</td>
		      <td>190000</td>
		      <td>Киргизия</td>
		      <td>12,06</td>
		   </tr>
		   <tr>
		      <td>18</td>
		      <td>2,85
		      <td>6</td>
		      <td>543,5</td>
		      <td>190000</td>
		      <td>Киргизия</td>
		      <td>17,1</td>
		   </tr>
		</table>
		<table>
		   <caption>СТАЛЬ ЛИСТОВАЯ  Х/К  ГОСТ 19904-90</caption>
		   <tr>
		      <th rowspan="2" class="first">Толщина, мм</th>
		      <th rowspan="2">Вес за ед.кг.</th>
		      <th rowspan="2">Размер,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Примечание</th>
		   </tr>
		   <tr>
		      <td class="first">лист</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>0,4</td>
		      <td>6,28
		      <td>1*2</td>
		      <td>1628,52</td>
		      <td>259000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>0,5</td>
		      <td>7,95
		      <td>1*2</td>
		      <td>2045,15</td>
		      <td>257000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>0,7</td>
		      <td>11,7
		      <td>1*2</td>
		      <td>2938,7</td>
		      <td>251000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>0,9</td>
		      <td>14,2
		      <td>1*2</td>
		      <td>3566,2</td>
		      <td>251000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>0,9</td>
		      <td>22
		      <td>1,25*2,5</td>
		      <td>5524</td>
		      <td>251000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1</td>
		      <td>16
		      <td>1*2</td>
		      <td>3954</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1</td>
		      <td>27
		      <td>1,25*2,5</td>
		      <td>6671</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,2</td>
		      <td>20
		      <td>1*2</td>
		      <td>4942</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,2</td>
		      <td>30,5
		      <td>1,25*2,5</td>
		      <td>7535,5</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,4</td>
		      <td>22
		      <td>1*2</td>
		      <td>5436</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,4</td>
		      <td>36
		      <td>1,25*2,5</td>
		      <td>8894</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,5</td>
		      <td>23,7
		      <td>1*2</td>
		      <td>5855,9</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,5</td>
		      <td>37,4
		      <td>1,25*2,5</td>
		      <td>9239,8</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,8</td>
		      <td>29
		      <td>1*2</td>
		      <td>7165</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>2</td>
		      <td>32
		      <td>1*2</td>
		      <td>7906</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>2</td>
		      <td>51
		      <td>1,25*2,5</td>
		      <td>12599</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		</table>
		<table>
		   <caption>СТАЛЬ ЛИСТОВАЯ  Г/К  ГОСТ 19903-74</caption>
		   <tr>
		      <th rowspan="2" class="first">Толщина, мм</th>
		      <th rowspan="2">Вес за ед.кг.</th>
		      <th rowspan="2">Размер,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Примечание</th>
		   </tr>
		   <tr>
		      <td class="first">лист</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>2</td>
		      <td>33,3
		      <td>1*2</td>
		      <td>8127,2</td>
		      <td>244000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>2</td>
		      <td>52,5
		      <td>1,25*2,5</td>
		      <td>12812</td>
		      <td>244000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>3</td>
		      <td>52
		      <td>1*2</td>
		      <td>12482</td>
		      <td>240000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>3</td>
		      <td>77,5
		      <td>1,25*2,5</td>
		      <td>18602</td>
		      <td>240000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>4</td>
		      <td>298
		      <td>1,5*6</td>
		      <td>70330</td>
		      <td>236000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>5</td>
		      <td>360
		      <td>1,5*6</td>
		      <td>83162</td>
		      <td>231000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>6</td>
		      <td>434
		      <td>1,5*6</td>
		      <td>100256</td>
		      <td>231000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>8</td>
		      <td>575
		      <td>1,5*6</td>
		      <td>132827</td>
		      <td>231000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>10</td>
		      <td>730
		      <td>1,5*6</td>
		      <td>168632</td>
		      <td>231000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>10</td>
		      <td>475
		      <td>1*6</td>
		      <td>109727</td>
		      <td>231000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>12</td>
		      <td>848
		      <td>1,5*6</td>
		      <td>195890</td>
		      <td>231000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>3 РИФЛЕНЫЙ</td>
		      <td>83,1
		      <td>1,25*2,5</td>
		      <td>21275,6</td>
		      <td>256000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>4 РИФЛЕНЫЙ</td>
		      <td>295
		      <td>1,5*6</td>
		      <td>73752</td>
		      <td>250000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>5 РИФЛЕНЫЙ</td>
		      <td>365
		      <td>1,5*6</td>
		      <td>90157</td>
		      <td>247000</td>
		      <td>Arcelor Mittal</td>
		      <td></td>
		   </tr>
		</table>
		<table>
		   <caption>СТАЛЬ ЛИСТОВАЯ  ПВЛ</caption>
		   <tr>
		      <th rowspan="2" class="first">Толщина, мм</th>
		      <th rowspan="2">Вес за ед.кг.</th>
		      <th rowspan="2">Рабочая ширина</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Примечание</th>
		   </tr>
		   <tr>
		      <td class="first">лист</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>4</td>
		      <td>24
		      <td>1,60*1</td>
		      <td>6552</td>
		      <td>273000</td>
		      <td>ТОО IRON</td>
		      <td></td>
		   </tr>
		</table>
		<table>
		   <caption>СТАЛЬ УГЛОВАЯ</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>30*2</td>
		      <td>1,1
		      <td>6</td>
		      <td>227,5</td>
		      <td>205000</td>
		      <td>Казахстан</td>
		      <td>6,6</td>
		   </tr>
		   <tr>
		      <td>30*3</td>
		      <td>1,35
		      <td>6</td>
		      <td>278,75</td>
		      <td>205000</td>
		      <td>Казахстан</td>
		      <td>8,1</td>
		   </tr>
		   <tr>
		      <td>40*2</td>
		      <td>1,3
		      <td>6</td>
		      <td>268,5</td>
		      <td>205000</td>
		      <td>Казахстан</td>
		      <td>7,8</td>
		   </tr>
		   <tr>
		      <td>40*3</td>
		      <td>2
		      <td>6</td>
		      <td>412</td>
		      <td>205000</td>
		      <td>Казахстан</td>
		      <td>12</td>
		   </tr>
		   <tr>
		      <td>40*4</td>
		      <td>2,36
		      <td>6</td>
		      <td>485,8</td>
		      <td>205000</td>
		      <td>Казахстан</td>
		      <td>14,16</td>
		   </tr>
		   <tr>
		      <td>50*3</td>
		      <td>2,4
		      <td>6</td>
		      <td>494</td>
		      <td>205000</td>
		      <td>Казахстан</td>
		      <td>14,4</td>
		   </tr>
		   <tr>
		      <td>50*4</td>
		      <td>3,15
		      <td>6</td>
		      <td>647,75</td>
		      <td>205000</td>
		      <td>Казахстан</td>
		      <td>18,9</td>
		   </tr>
		   <tr>
		      <td>63*4</td>
		      <td>3,55
		      <td>6</td>
		      <td>729,75</td>
		      <td>205000</td>
		      <td>Казахстан</td>
		      <td>21,3</td>
		   </tr>
		</table>
		<table>
		   <caption>СТАЛЬ УГЛОВАЯ  ГОСТ 8509-72</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>25*4</td>
		      <td>1,5
		      <td>6,05</td>
		      <td>383</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>9,075</td>
		   </tr>
		   <tr>
		      <td>32*4</td>
		      <td>2,1
		      <td>6,05/12,05</td>
		      <td>535,4</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>12,71/25,31</td>
		   </tr>
		   <tr>
		      <td>40*4</td>
		      <td>2,45
		      <td>11,75</td>
		      <td>624,3</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>28,7875</td>
		   </tr>
		   <tr>
		      <td>45*4</td>
		      <td>2,8
		      <td>11,75</td>
		      <td>713,2</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>32,9</td>
		   </tr>
		   <tr>
		      <td>50*4</td>
		      <td>3,15
		      <td>11,75</td>
		      <td>802,1</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>37,0125</td>
		   </tr>
		   <tr>
		      <td>50*5</td>
		      <td>3,84
		      <td>11,75/12,05</td>
		      <td>977,36</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>45,12/46,27</td>
		   </tr>
		   <tr>
		      <td>50*5</td>
		      <td>3,6
		      <td>6</td>
		      <td>916,4</td>
		      <td>254000</td>
		      <td>Казахстан</td>
		      <td>21,6</td>
		   </tr>
		   <tr>
		      <td>63*5</td>
		      <td>4,9
		      <td>11,75/12,05</td>
		      <td>1246,6</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>57,58/59,04</td>
		   </tr>
		   <tr>
		      <td>63*6</td>
		      <td>5,97
		      <td>11,75</td>
		      <td>1518,38</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>70,1475</td>
		   </tr>
		   <tr>
		      <td>70*5</td>
		      <td>5,45
		      <td>11,75</td>
		      <td>1386,3</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>64,0375</td>
		   </tr>
		   <tr>
		      <td>70*6</td>
		      <td>6,55
		      <td>11,75</td>
		      <td>1665,7</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>76,9625</td>
		   </tr>
		   <tr>
		      <td>75*5</td>
		      <td>5,9
		      <td>11,75</td>
		      <td>1500,6</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>69,325</td>
		   </tr>
		   <tr>
		      <td>75*6</td>
		      <td>6,96
		      <td>11,75</td>
		      <td>1769,84</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>81,78</td>
		   </tr>
		   <tr>
		      <td>80*6</td>
		      <td>7,2
		      <td>11,75</td>
		      <td>1830,8</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>84,6</td>
		   </tr>
		   <tr>
		      <td>90*7</td>
		      <td>9,64
		      <td>11,75</td>
		      <td>2450,56</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>113,27</td>
		   </tr>
		   <tr>
		      <td>100*7</td>
		      <td>10,75
		      <td>11,75</td>
		      <td>2732,5</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>126,3125</td>
		   </tr>
		   <tr>
		      <td>110*7</td>
		      <td>11,55
		      <td>11,75</td>
		      <td>2935,7</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>135,7125</td>
		   </tr>
		   <tr>
		      <td>125*8</td>
		      <td>15,8
		      <td>11,75</td>
		      <td>4015,2</td>
		      <td>254000</td>
		      <td>Россия</td>
		      <td>185,65</td>
		   </tr>
		</table>
		<table>
		   <caption>ШВЕЛЛЕР  ГОСТ 8240-97</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>5 У</td>
		      <td>5,035
		      <td>11,75</td>
		      <td>1537,675</td>
		      <td>305000</td>
		      <td>Россия</td>
		      <td>59,16125</td>
		   </tr>
		   <tr>
		      <td>6,5 У</td>
		      <td>6
		      <td>12,05</td>
		      <td>1820</td>
		      <td>303000</td>
		      <td>Россия</td>
		      <td>72,3</td>
		   </tr>
		   <tr>
		      <td>8 У/8П</td>
		      <td>7,4
		      <td>11,75/12,05</td>
		      <td>2244,2</td>
		      <td>303000</td>
		      <td>Россия</td>
		      <td>86,95/89,17</td>
		   </tr>
		   <tr>
		      <td>8</td>
		      <td>6,8
		      <td>6</td>
		      <td>1600</td>
		      <td>235000</td>
		      <td>Казахстан</td>
		      <td>40,8</td>
		   </tr>
		   <tr>
		      <td>10 У/ 10П</td>
		      <td>8,9
		      <td>11,75/12,05</td>
		      <td>2698,7</td>
		      <td>303000</td>
		      <td>Россия</td>
		      <td>104,58/107,25</td>
		   </tr>
		   <tr>
		      <td>12 У/ 12П</td>
		      <td>10,75
		      <td>11,75/12,05</td>
		      <td>3280,75</td>
		      <td>305000</td>
		      <td>Россия</td>
		      <td>126,31/129,54</td>
		   </tr>
		   <tr>
		      <td>12</td>
		      <td>7,8
		      <td>6</td>
		      <td>1835</td>
		      <td>235000</td>
		      <td>Казахстан</td>
		      <td>46,8</td>
		   </tr>
		   <tr>
		      <td>14 У/ 14П</td>
		      <td>12,9/12,65
		      <td>11,75/12,05</td>
		      <td>3872/3797</td>
		      <td>303000</td>
		      <td>Россия</td>
		      <td>151,58/152,43</td>
		   </tr>
		   <tr>
		      <td>16 У/16П</td>
		      <td>14,65
		      <td>11,75/12,05</td>
		      <td>4440,95</td>
		      <td>303000</td>
		      <td>Россия</td>
		      <td>171,55/175,93</td>
		   </tr>
		</table>
		<table>
		   <caption>ШВЕЛЛЕР ОБЛЕГЧЕННЫЙ </caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>12 (профиль М-образный)</td>
		      <td>6,85
		      <td>12</td>
		      <td>1043,2</td>
		      <td>152000</td>
		      <td>Казахстан</td>
		      <td>82,2</td>
		   </tr>
		   <tr>
		      <td>160*50*4</td>
		      <td>7,77
		      <td>6</td>
		      <td>2084,36</td>
		      <td>268000</td>
		      <td>Казахстан</td>
		      <td>46,62</td>
		   </tr>
		</table>
		<table>
		   <caption>БАЛКА  ГОСТ 8239-89</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>10 У</td>
		      <td>9,82
		      <td>12,05</td>
		      <td>3439</td>
		      <td>350000</td>
		      <td>Украина</td>
		      <td>118,331</td>
		   </tr>
		   <tr>
		      <td>12 Б1</td>
		      <td>9,1
		      <td>12,05</td>
		      <td>3187</td>
		      <td>350000</td>
		      <td>Россия</td>
		      <td>109,655</td>
		   </tr>
		   <tr>
		      <td>14 Б1</td>
		      <td>11,5
		      <td>12,05</td>
		      <td>4027</td>
		      <td>350000</td>
		      <td>Россия</td>
		      <td>138,575</td>
		   </tr>
		   <tr>
		      <td>16 Б1</td>
		      <td>12,9
		      <td>12,05</td>
		      <td>4517</td>
		      <td>350000</td>
		      <td>Россия</td>
		      <td>155,445</td>
		   </tr>
		   <tr>
		      <td>20 Б1</td>
		      <td>21,7
		      <td>12,05</td>
		      <td>7163</td>
		      <td>330000</td>
		      <td>Россия</td>
		      <td>261,485</td>
		   </tr>
		   <tr>
		      <td>25 Б1</td>
		      <td>25,8
		      <td>12,05</td>
		      <td>8516</td>
		      <td>330000</td>
		      <td>Россия</td>
		      <td>310,89</td>
		   </tr>
		</table>
		<table>
		   <caption>ТРУБА ЭЛЕКТРОСВАРНАЯ  ГОСТ 10704-91, 10705-80</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>15*2 (21,3)</td>
		      <td>1,1
		      <td>6</td>
		      <td>281,4</td>
		      <td>254000</td>
		      <td>Arcelor Mittal/Казахстан</td>
		      <td>6,6</td>
		   </tr>
		   <tr>
		      <td>20*2 (27)</td>
		      <td>1,35
		      <td>6</td>
		      <td>344,9</td>
		      <td>254000</td>
		      <td>Arcelor Mittal/Казахстан</td>
		      <td>8,1</td>
		   </tr>
		   <tr>
		      <td>25*1,8</td>
		      <td>1,55
		      <td>6</td>
		      <td>395,7</td>
		      <td>254000</td>
		      <td>Казахстан</td>
		      <td>9,3</td>
		   </tr>
		   <tr>
		      <td>25*2 (33,7)</td>
		      <td>1,76
		      <td>6</td>
		      <td>440,24</td>
		      <td>249000</td>
		      <td>Arcelor Mittal/Казахстан</td>
		      <td>10,56</td>
		   </tr>
		   <tr>
		      <td>32*2</td>
		      <td>2,1
		      <td>6</td>
		      <td>524,9</td>
		      <td>249000</td>
		      <td>Arcelor Mittal</td>
		      <td>12,6</td>
		   </tr>
		   <tr>
		      <td>32*2 (42)          </td>
		      <td>2,1
		      <td>6</td>
		      <td>518,6</td>
		      <td>246000</td>
		      <td>Казахстан</td>
		      <td>12,6</td>
		   </tr>
		   <tr>
		      <td>40*1,8 (48)          </td>
		      <td>2,18
		      <td>6</td>
		      <td>551,36</td>
		      <td>252000</td>
		      <td>Казахстан</td>
		      <td>13,08</td>
		   </tr>
		   <tr>
		      <td>40*2 (48)          </td>
		      <td>2,4
		      <td>6</td>
		      <td>599,6</td>
		      <td>249000</td>
		      <td>Arcelor Mittal/Казахстан</td>
		      <td>14,4</td>
		   </tr>
		   <tr>
		      <td>60*1,8</td>
		      <td>2,75
		      <td>6</td>
		      <td>695</td>
		      <td>252000</td>
		      <td>Казахстан</td>
		      <td>16,5</td>
		   </tr>
		   <tr>
		      <td>57*2 (60)</td>
		      <td>3,05
		      <td>6</td>
		      <td>761,45</td>
		      <td>249000</td>
		      <td>Arcelor Mittal/Казахстан</td>
		      <td>18,3</td>
		   </tr>
		   <tr>
		      <td>76*1,8</td>
		      <td>3,5
		      <td>6</td>
		      <td>884</td>
		      <td>252000</td>
		      <td>Казахстан</td>
		      <td>21</td>
		   </tr>
		   <tr>
		      <td>76*2</td>
		      <td>3,96
		      <td>6</td>
		      <td>999,92</td>
		      <td>252000</td>
		      <td>Казахстан</td>
		      <td>23,76</td>
		   </tr>
		   <tr>
		      <td>76*2,7</td>
		      <td>5
		      <td>10</td>
		      <td>1247</td>
		      <td>249000</td>
		      <td>Казахстан</td>
		      <td>50</td>
		   </tr>
		   <tr>
		      <td>89*2</td>
		      <td>4,55
		      <td>6,05</td>
		      <td>1148,6</td>
		      <td>252000</td>
		      <td>Казахстан</td>
		      <td>27,5275</td>
		   </tr>
		   <tr>
		      <td>89*2,7</td>
		      <td>6,2
		      <td>10</td>
		      <td>1539,6</td>
		      <td>248000</td>
		      <td>Казахстан</td>
		      <td>62</td>
		   </tr>
		   <tr>
		      <td>102*3</td>
		      <td>6,9
		      <td>11,75</td>
		      <td>1768,4</td>
		      <td>256000</td>
		      <td>Казахстан</td>
		      <td>81,075</td>
		   </tr>
		   <tr>
		      <td>108*2,7 (снятая фаска)</td>
		      <td>7,3
		      <td>11,75</td>
		      <td>1856,2</td>
		      <td>254000</td>
		      <td> TOO Sonik</td>
		      <td>85,775</td>
		   </tr>
		   <tr>
		      <td>108*3,2 (снятая фаска)</td>
		      <td>8,52
		      <td>11,75</td>
		      <td>2166,08</td>
		      <td>254000</td>
		      <td> TOO Sonik</td>
		      <td>100,11</td>
		   </tr>
		   <tr>
		      <td>133*2,7 (снятая фаска)</td>
		      <td>9
		      <td>11,75</td>
		      <td>2288</td>
		      <td>254000</td>
		      <td> TOO Sonik</td>
		      <td>105,75</td>
		   </tr>
		   <tr>
		      <td>159*2,7 (снятая фаска)</td>
		      <td>11
		      <td>11,75</td>
		      <td>2796</td>
		      <td>254000</td>
		      <td> TOO Sonik</td>
		      <td>129,25</td>
		   </tr>
		   <tr>
		      <td>159*3,5</td>
		      <td>13,3
		      <td>11,75</td>
		      <td>3406,8</td>
		      <td>256000</td>
		      <td>Казахстан</td>
		      <td>156,275</td>
		   </tr>
		   <tr>
		      <td>159*4 (снятая фаска)</td>
		      <td>16
		      <td>11,75</td>
		      <td>4066</td>
		      <td>254000</td>
		      <td> TOO Sonik</td>
		      <td>188</td>
		   </tr>
		   <tr>
		      <td>219*5 (снятая фаска)</td>
		      <td>26,8
		      <td>11,75</td>
		      <td>6809,2</td>
		      <td>254000</td>
		      <td> TOO Sonik</td>
		      <td>314,9</td>
		   </tr>
		</table>
		<table>
		   <caption>ТРУБА ВОДОГАЗОПРОВОДНАЯ ГОСТ 3262-75</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Вес 1 штуки</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>15*2,5 (21,3)</td>
		      <td>1,25
		      <td>5,85/8</td>
		      <td>312</td>
		      <td>248000</td>
		      <td>Arcelor Mittal </td>
		      <td>7,31/10</td>
		   </tr>
		   <tr>
		      <td>20*2,5 (26,8)</td>
		      <td>1,59
		      <td>5,85</td>
		      <td>396,32</td>
		      <td>248000</td>
		      <td>Arcelor Mittal</td>
		      <td>9,3015</td>
		   </tr>
		   <tr>
		      <td>25*2,8</td>
		      <td>2,25
		      <td>5,85</td>
		      <td>548,75</td>
		      <td>243000</td>
		      <td>Arcelor Mittal</td>
		      <td>13,1625</td>
		   </tr>
		   <tr>
		      <td>32*2,5</td>
		      <td>2,65
		      <td>5,85</td>
		      <td>653,9</td>
		      <td>246000</td>
		      <td>Arcelor Mittal</td>
		      <td>15,5025</td>
		   </tr>
		   <tr>
		      <td>32*2,8 (42,3)</td>
		      <td>2,86
		      <td>5,85</td>
		      <td>699,84</td>
		      <td>244000</td>
		      <td>Arcelor Mittal</td>
		      <td>16,731</td>
		   </tr>
		   <tr>
		      <td>40*3 (48)</td>
		      <td>3,48
		      <td>10</td>
		      <td>847,64</td>
		      <td>243000</td>
		      <td>Arcelor Mittal</td>
		      <td>34,8</td>
		   </tr>
		   <tr>
		      <td>50*3 (60)</td>
		      <td>4,5
		      <td>10</td>
		      <td>1095,5</td>
		      <td>243000</td>
		      <td>Arcelor Mittal</td>
		      <td>45</td>
		   </tr>
		   <tr>
		      <td>65*3,2 (76)</td>
		      <td>6,05
		      <td>10</td>
		      <td>1472,15</td>
		      <td>243000</td>
		      <td>Arcelor Mittal </td>
		      <td>60,5</td>
		   </tr>
		   <tr>
		      <td>80*3,5(89) </td>
		      <td>7,55
		      <td>10</td>
		      <td>1836,65</td>
		      <td>243000</td>
		      <td>Arcelor Mittal </td>
		      <td>75,5</td>
		   </tr>
		</table>
		<table>
		   <caption>ПОЛОСА</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Пимечание</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>30*4</td>
		      <td>1
		      <td>6</td>
		      <td>155/177</td>
		      <td>153000/175000</td>
		      <td></td>
		      <td>6</td>
		   </tr>
		   <tr>
		      <td>40*4</td>
		      <td>1,35
		      <td>6</td>
		      <td>272/299</td>
		      <td>200000/220000</td>
		      <td></td>
		      <td>8,1</td>
		   </tr>
		   <tr>
		      <td>50*4 (в рулоне)</td>
		      <td>1,6
		      <td></td>
		      <td>322</td>
		      <td>200000</td>
		      <td>Россия</td>
		      <td>вес бухты 1 тн.</td>
		   </tr>
		</table>
		<table>
		   <caption>ЭЛЕКТРОДЫ СВАРОЧНЫЕ</caption>
		   <tr>
		      <th rowspan="2" class="first">Марка электродов</th>
		      <th rowspan="2">Диаметр, мм</th>
		      <th rowspan="2">Вес пачки, кг</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Пимечание</th>
		   </tr>
		   <tr>
		      <td class="first">пачка</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>МР-3</td>
		      <td>2
		      <td>5</td>
		      <td>1900</td>
		      <td>380000</td>
		      <td>Китай</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>МР-3</td>
		      <td>3
		      <td>5</td>
		      <td>1800</td>
		      <td>360000</td>
		      <td>Китай</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>МР-3</td>
		      <td>4
		      <td>5</td>
		      <td>1800</td>
		      <td>360000</td>
		      <td>Китай</td>
		      <td></td>
		   </tr>
		</table>
		<table>
		   <caption>БРУС ДЕРЕВЯННЫЙ</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2"></th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Пимечание</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">1м/куб</td>
		   </tr>
		   <tr>
		      <td>100*50</td>
		      <td>
		      <td>2,7</td>
		      <td>450</td>
		      <td>30000</td>
		      <td></td>
		      <td>щиты вагонные</td>
		   </tr>
		   <tr>
		      <td>100*100</td>
		      <td>
		      <td>2,7</td>
		      <td>850</td>
		      <td>30000</td>
		      <td></td>
		      <td>щиты вагонные</td>
		   </tr>
		</table>
		<table>
		   <caption>ТРУБА ПРОФИЛЬНАЯ ГОСТ 8639-82</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 пм, кг.</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Пимечание</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>15*15*0,9</td>
		      <td>0,395
		      <td>6</td>
		      <td>111,81</td>
		      <td>278000</td>
		      <td>TOO IRON</td>
		      <td>2,37</td>
		   </tr>
		   <tr>
		      <td>15*15*1,2</td>
		      <td>0,6
		      <td>6</td>
		      <td>167</td>
		      <td>275000</td>
		      <td>TOO IRON</td>
		      <td>3,6</td>
		   </tr>
		   <tr>
		      <td>15*15*1,4 х/к</td>
		      <td>0,61
		      <td>6</td>
		      <td>168,53</td>
		      <td>273000</td>
		      <td>TOO IRON</td>
		      <td>3,66</td>
		   </tr>
		   <tr>
		      <td>15*15*1,4 </td>
		      <td>0,66
		      <td>6</td>
		      <td>182,18</td>
		      <td>273000</td>
		      <td>TOO IRON</td>
		      <td>3,96</td>
		   </tr>
		   <tr>
		      <td>15*15*1,5</td>
		      <td>0,71
		      <td>6</td>
		      <td>195,83</td>
		      <td>273000</td>
		      <td>TOO IRON</td>
		      <td>4,26</td>
		   </tr>
		   <tr>
		      <td>20*20*0,9</td>
		      <td>0,565
		      <td>6</td>
		      <td>155,68</td>
		      <td>272000</td>
		      <td>TOO IRON</td>
		      <td>3,39</td>
		   </tr>
		   <tr>
		      <td>20*20*1,2</td>
		      <td>0,75
		      <td>6</td>
		      <td>203,75</td>
		      <td>269000</td>
		      <td>TOO IRON</td>
		      <td>4,5</td>
		   </tr>
		   <tr>
		      <td>20*20*1,4 х/к</td>
		      <td>0,83
		      <td>6</td>
		      <td>225,27</td>
		      <td>269000</td>
		      <td>TOO IRON</td>
		      <td>4,98</td>
		   </tr>
		   <tr>
		      <td>20*20*1,4 </td>
		      <td>0,88
		      <td>6</td>
		      <td>238,72</td>
		      <td>269000</td>
		      <td>TOO IRON</td>
		      <td>5,28</td>
		   </tr>
		   <tr>
		      <td>20*20*1,5</td>
		      <td>0,93
		      <td>6</td>
		      <td>252,17</td>
		      <td>269000</td>
		      <td>TOO IRON</td>
		      <td>5,58</td>
		   </tr>
		   <tr>
		      <td>25*25*1,2</td>
		      <td>0,97
		      <td>6</td>
		      <td>257,11</td>
		      <td>263000</td>
		      <td>TOO IRON</td>
		      <td>5,82</td>
		   </tr>
		   <tr>
		      <td>25*25*1,4</td>
		      <td>1,1
		      <td>6</td>
		      <td>290,2</td>
		      <td>262000</td>
		      <td>TOO IRON</td>
		      <td>6,6</td>
		   </tr>
		   <tr>
		      <td>25*25*1,5</td>
		      <td>1,2
		      <td>6</td>
		      <td>314</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>7,2</td>
		   </tr>
		   <tr>
		      <td>25*25*1,8</td>
		      <td>1,45
		      <td>6</td>
		      <td>368,85</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>8,7</td>
		   </tr>
		   <tr>
		      <td>30*30*1,4 х/к</td>
		      <td>1,21
		      <td>6</td>
		      <td>316,6</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>7,26</td>
		   </tr>
		   <tr>
		      <td>30*30*1,4</td>
		      <td>1,37
		      <td>6</td>
		      <td>360,94</td>
		      <td>262000</td>
		      <td>TOO IRON</td>
		      <td>8,22</td>
		   </tr>
		   <tr>
		      <td>30*30*1,5</td>
		      <td>1,43
		      <td>6</td>
		      <td>373,8</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>8,58</td>
		   </tr>
		   <tr>
		      <td>30*30*1,8</td>
		      <td>1,74
		      <td>6</td>
		      <td>442,22</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>10,44</td>
		   </tr>
		   <tr>
		      <td>40*20*0,9</td>
		      <td>0,848
		      <td>6</td>
		      <td>229,264</td>
		      <td>268000</td>
		      <td>TOO IRON</td>
		      <td>5,088</td>
		   </tr>
		   <tr>
		      <td>40*20*1,2 </td>
		      <td>1,19
		      <td>6</td>
		      <td>314,97</td>
		      <td>263000</td>
		      <td>TOO IRON</td>
		      <td>7,14</td>
		   </tr>
		   <tr>
		      <td>40*20*1,4  х/к</td>
		      <td>1,3
		      <td>6</td>
		      <td>340</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>7,8</td>
		   </tr>
		   <tr>
		      <td>40*20*1,4  </td>
		      <td>1,4
		      <td>6</td>
		      <td>368,8</td>
		      <td>262000</td>
		      <td>TOO IRON</td>
		      <td>8,4</td>
		   </tr>
		   <tr>
		      <td>40*20*1,5  </td>
		      <td>1,45
		      <td>6</td>
		      <td>379</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>8,7</td>
		   </tr>
		   <tr>
		      <td>40*20*1,8</td>
		      <td>1,7
		      <td>6</td>
		      <td>432,1</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>10,2</td>
		   </tr>
		   <tr>
		      <td>40*20*2</td>
		      <td>1,9
		      <td>6</td>
		      <td>473,2</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>11,4</td>
		   </tr>
		   <tr>
		      <td>40*25*1,5  </td>
		      <td>1,53
		      <td>6</td>
		      <td>399,8</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>9,18</td>
		   </tr>
		   <tr>
		      <td>40*25*1,8</td>
		      <td>1,85
		      <td>6</td>
		      <td>470,05</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>11,1</td>
		   </tr>
		   <tr>
		      <td>40*40*1,2</td>
		      <td>1,51
		      <td>6</td>
		      <td>399,13</td>
		      <td>263000</td>
		      <td>TOO IRON</td>
		      <td>9,06</td>
		   </tr>
		   <tr>
		      <td>40*40*1,4 х/к</td>
		      <td>1,75
		      <td>6</td>
		      <td>457</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>10,5</td>
		   </tr>
		   <tr>
		      <td>40*40*1,4 </td>
		      <td>1,84
		      <td>6</td>
		      <td>484,08</td>
		      <td>262000</td>
		      <td>TOO IRON</td>
		      <td>11,04</td>
		   </tr>
		   <tr>
		      <td>40*40*1,5 </td>
		      <td>1,96
		      <td>6</td>
		      <td>511,6</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>11,76</td>
		   </tr>
		   <tr>
		      <td>40*40*1,8</td>
		      <td>2,24
		      <td>6</td>
		      <td>568,72</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>13,44</td>
		   </tr>
		   <tr>
		      <td>40*40*2</td>
		      <td>2,5
		      <td>6</td>
		      <td>622</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>15</td>
		   </tr>
		   <tr>
		      <td>40*40*3</td>
		      <td>3,3
		      <td>6</td>
		      <td>830,3</td>
		      <td>251000</td>
		      <td>TOO IRON</td>
		      <td>19,8</td>
		   </tr>
		   <tr>
		      <td>50*25*1,4</td>
		      <td>1,75
		      <td>6</td>
		      <td>460,5</td>
		      <td>262000</td>
		      <td>TOO IRON</td>
		      <td>10,5</td>
		   </tr>
		   <tr>
		      <td>50*25*1,5</td>
		      <td>1,79
		      <td>6</td>
		      <td>467,4</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>10,74</td>
		   </tr>
		   <tr>
		      <td>50*25*1,8</td>
		      <td>2,08
		      <td>6</td>
		      <td>528,24</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>12,48</td>
		   </tr>
		   <tr>
		      <td>50*25*2</td>
		      <td>2,37
		      <td>6</td>
		      <td>589,76</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>14,22</td>
		   </tr>
		   <tr>
		      <td>50*50*1,4 г/к</td>
		      <td>2,28
		      <td>6</td>
		      <td>599,36</td>
		      <td>262000</td>
		      <td>TOO IRON</td>
		      <td>13,68</td>
		   </tr>
		   <tr>
		      <td>50*50*1,5</td>
		      <td>2,39
		      <td>6</td>
		      <td>623,4</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>14,34</td>
		   </tr>
		   <tr>
		      <td>50*50*1,8</td>
		      <td>2,9
		      <td>6</td>
		      <td>735,7</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>17,4</td>
		   </tr>
		   <tr>
		      <td>50*50*2</td>
		      <td>3,2
		      <td>6</td>
		      <td>795,6</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>19,2</td>
		   </tr>
		   <tr>
		      <td>50*50*3</td>
		      <td>4,3
		      <td>6</td>
		      <td>1068,4</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>25,8</td>
		   </tr>
		   <tr>
		      <td>60*40*1,4 х/к</td>
		      <td>2,2
		      <td>6</td>
		      <td>574</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>13,2</td>
		   </tr>
		   <tr>
		      <td>60*40*1,4</td>
		      <td>2,4
		      <td>6</td>
		      <td>630,8</td>
		      <td>262000</td>
		      <td>TOO IRON</td>
		      <td>14,4</td>
		   </tr>
		   <tr>
		      <td>60*40*1,5</td>
		      <td>2,44
		      <td>6</td>
		      <td>636,4</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>14,64</td>
		   </tr>
		   <tr>
		      <td>60*40*1,8</td>
		      <td>2,9
		      <td>6</td>
		      <td>735,7</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>17,4</td>
		   </tr>
		   <tr>
		      <td>60*40*2</td>
		      <td>3,2
		      <td>6</td>
		      <td>795,6</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>19,2</td>
		   </tr>
		   <tr>
		      <td>60*40*3</td>
		      <td>4,3
		      <td>6</td>
		      <td>1068,4</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>25,8</td>
		   </tr>
		   <tr>
		      <td>60*60*1,4 г/к</td>
		      <td>2,75
		      <td>6</td>
		      <td>722,5</td>
		      <td>262000</td>
		      <td>TOO IRON</td>
		      <td>16,5</td>
		   </tr>
		   <tr>
		      <td>60*60*1,5</td>
		      <td>2,9
		      <td>6</td>
		      <td>756</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>17,4</td>
		   </tr>
		   <tr>
		      <td>60*60*1,8</td>
		      <td>3,53
		      <td>6</td>
		      <td>895,09</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>21,18</td>
		   </tr>
		   <tr>
		      <td>60*60*2  </td>
		      <td>3,8
		      <td>6</td>
		      <td>944,4</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>22,8</td>
		   </tr>
		   <tr>
		      <td>60*60*2,5</td>
		      <td>4,5
		      <td>6</td>
		      <td>1113,5</td>
		      <td>247000</td>
		      <td>TOO IRON</td>
		      <td>27</td>
		   </tr>
		   <tr>
		      <td>60*60*3</td>
		      <td>5,35
		      <td>6</td>
		      <td>1318,1</td>
		      <td>246000</td>
		      <td>TOO IRON</td>
		      <td>32,1</td>
		   </tr>
		   <tr>
		      <td>80*40*1,5</td>
		      <td>2,98
		      <td>6</td>
		      <td>776,8</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>17,88</td>
		   </tr>
		   <tr>
		      <td>80*40*1,8</td>
		      <td>3,4
		      <td>6</td>
		      <td>862,2</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>20,4</td>
		   </tr>
		   <tr>
		      <td>80*40*2</td>
		      <td>3,82
		      <td>6</td>
		      <td>949,36</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>22,92</td>
		   </tr>
		   <tr>
		      <td>80*40*3</td>
		      <td>5,2
		      <td>6</td>
		      <td>1281,2</td>
		      <td>246000</td>
		      <td>TOO IRON</td>
		      <td>31,2</td>
		   </tr>
		   <tr>
		      <td>80*80*1,5</td>
		      <td>3,8
		      <td>6</td>
		      <td>990</td>
		      <td>260000</td>
		      <td>TOO IRON</td>
		      <td>22,8</td>
		   </tr>
		   <tr>
		      <td>80*80*1,8</td>
		      <td>4,68
		      <td>6</td>
		      <td>1186,04</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>28,08</td>
		   </tr>
		   <tr>
		      <td>80*80*2</td>
		      <td>5,15
		      <td>6</td>
		      <td>1279,2</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>30,9</td>
		   </tr>
		   <tr>
		      <td>80*80*3</td>
		      <td>7,33
		      <td>6</td>
		      <td>1805,18</td>
		      <td>246000</td>
		      <td>TOO IRON</td>
		      <td>43,98</td>
		   </tr>
		   <tr>
		      <td>80*80*3,5</td>
		      <td>8,65
		      <td>6</td>
		      <td>2060,7</td>
		      <td>238000</td>
		      <td>TOO IRON</td>
		      <td>51,9</td>
		   </tr>
		   <tr>
		      <td>80*80*4</td>
		      <td>10,1
		      <td>6</td>
		      <td>2567,4</td>
		      <td>254000</td>
		      <td>TOO Sonik</td>
		      <td>60,6</td>
		   </tr>
		   <tr>
		      <td>100*50*1,8</td>
		      <td>4,43
		      <td>6</td>
		      <td>1122,79</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>26,58</td>
		   </tr>
		   <tr>
		      <td>100*50*2</td>
		      <td>4,75
		      <td>6</td>
		      <td>1180</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>28,5</td>
		   </tr>
		   <tr>
		      <td>100*50*3</td>
		      <td>6,5
		      <td>6</td>
		      <td>1601</td>
		      <td>246000</td>
		      <td>TOO IRON</td>
		      <td>39</td>
		   </tr>
		   <tr>
		      <td>100*100*1,8</td>
		      <td>5,7
		      <td>6</td>
		      <td>1444,1</td>
		      <td>253000</td>
		      <td>TOO IRON</td>
		      <td>34,2</td>
		   </tr>
		   <tr>
		      <td>100*100*2</td>
		      <td>6,533
		      <td>6</td>
		      <td>1622,184</td>
		      <td>248000</td>
		      <td>TOO IRON</td>
		      <td>39,198</td>
		   </tr>
		   <tr>
		      <td>100*100*3</td>
		      <td>9,2
		      <td>6</td>
		      <td>2265,2</td>
		      <td>246000</td>
		      <td>TOO IRON</td>
		      <td>55,2</td>
		   </tr>
		   <tr>
		      <td>100*100*4</td>
		      <td>12,5
		      <td>6</td>
		      <td>3177</td>
		      <td>254000</td>
		      <td>TOO Sonik</td>
		      <td>75</td>
		   </tr>
		   <tr>
		      <td>120*120*4</td>
		      <td>15
		      <td>12</td>
		      <td>3812</td>
		      <td>254000</td>
		      <td>TOO Sonik</td>
		      <td>180</td>
		   </tr>
		   <tr>
		      <td>140*140*4</td>
		      <td>17,4
		      <td>12</td>
		      <td>4421,6</td>
		      <td>254000</td>
		      <td>TOO Sonik</td>
		      <td>208,8</td>
		   </tr>
		   <tr>
		      <td>160*160*4</td>
		      <td>19,7
		      <td>12</td>
		      <td>5005,8</td>
		      <td>254000</td>
		      <td>TOO Sonik</td>
		      <td>236,4</td>
		   </tr>
		</table>
		<table>
		   <caption>РУЛОН Г/К</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Примечание</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>1,2*1000</td>
		      <td>от 4 до 6 тонн</td>
		      <td></td>
		      <td>254000</td>
		      <td>ММК</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,4*1000</td>
		      <td>от 11 до 13 тонн</td>
		      <td></td>
		      <td>252000</td>
		      <td>ММК</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,5*1000</td>
		      <td>от 11 до 13 тонн</td>
		      <td></td>
		      <td>249000</td>
		      <td>ММК</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,8*1250</td>
		      <td>от 11 до 13 тонн</td>
		      <td></td>
		      <td>242000</td>
		      <td>ММК</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>2*1250</td>
		      <td>от 11 до 13 тонн</td>
		      <td></td>
		      <td>238000</td>
		      <td>ММК</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>2,7*1250</td>
		      <td>от 11 до 13 тонн</td>
		      <td></td>
		      <td>234000</td>
		      <td>ММК</td>
		      <td></td>
		   </tr>
		</table>
		<table>
		   <caption>ПРОВОЛОКА</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес бухты, тн.</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Пимечание</th>
		   </tr>
		   <tr>
		      <td class="first">бухта</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>1,2 о/к  оцинкованная</td>
		      <td>0,025/0,05
		      <td></td>
		      <td>9500/19000</td>
		      <td>380000</td>
		      <td>Китай </td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>1,2 отожённая</td>
		      <td>бухты н/м
		      <td></td>
		      <td></td>
		      <td>320000</td>
		      <td>Казахстан</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>2,2 о/к  оцинкованная</td>
		      <td>0,05
		      <td></td>
		      <td>17000</td>
		      <td>340000</td>
		      <td>Китай </td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>2,8 о/к  оцинкованная</td>
		      <td>0,05
		      <td></td>
		      <td>17000</td>
		      <td>340000</td>
		      <td>Китай </td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>4,0 о/к  оцинкованная</td>
		      <td>0,05
		      <td></td>
		      <td>17000</td>
		      <td>340000</td>
		      <td>Китай </td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>ВР ф2,7</td>
		      <td>1,01
		      <td></td>
		      <td>227250</td>
		      <td>225000</td>
		      <td>Россия</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>ВР ф3,7</td>
		      <td>1,01
		      <td></td>
		      <td>222200</td>
		      <td>220000</td>
		      <td>Россия</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>ВР ф3,8</td>
		      <td>1,01
		      <td></td>
		      <td>222200</td>
		      <td>220000</td>
		      <td>Россия</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>ВР ф 4,8</td>
		      <td>1,01
		      <td></td>
		      <td>222200</td>
		      <td>220000</td>
		      <td>Россия</td>
		      <td></td>
		   </tr>
		</table>
		<table>
		   <caption>ПРОВОЛОКА ТЯНУТАЯ</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 пм, кг</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Производство</th>
		      <th rowspan="2">Пимечание</th>
		   </tr>
		   <tr>
		      <td class="first">метр</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>ВР ф3 (тянутая)</td>
		      <td>0,055
		      <td>3</td>
		      <td>15,585</td>
		      <td>247000</td>
		      <td>Россия</td>
		      <td>0,165</td>
		   </tr>
		   <tr>
		      <td>ВР ф4 (тянутая)</td>
		      <td>0,099
		      <td>3</td>
		      <td>25,661</td>
		      <td>239000</td>
		      <td>Россия</td>
		      <td>0,297</td>
		   </tr>
		   <tr>
		      <td>ВР ф5 (тянутая)</td>
		      <td>0,16
		      <td>3</td>
		      <td>39,92</td>
		      <td>237000</td>
		      <td>Россия</td>
		      <td>0,48</td>
		   </tr>
		</table>
		<table>
		   <caption>СЕТКА КЛАДОЧНАЯ ГОСТ 23279-83</caption>
		   <tr>
		      <th rowspan="2" class="first">Диаметр, мм</th>
		      <th rowspan="2">Вес за ед.кг</th>
		      <th rowspan="2">Длина,м</th>
		      <th colspan="2">Стоимость, тенге</th>
		      <th rowspan="2">Стоимость за тонну</th>
		      <th rowspan="2">Пимечание</th>
		   </tr>
		   <tr>
		      <td class="first">розница</td>
		      <td class="first">опт</td>
		   </tr>
		   <tr>
		      <td>Вр3 яч10*10 </td>
		      <td>3,2
		      <td>1*3</td>
		      <td>802</td>
		      <td>795,6</td>
		      <td>250000</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>Вр3 яч15*15</td>
		      <td>2,2
		      <td>1*3</td>
		      <td>552</td>
		      <td>547,6</td>
		      <td>250000</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>Вр3 яч12*36</td>
		      <td>0,7
		      <td>0,36*3</td>
		      <td>177</td>
		      <td>175,6</td>
		      <td>250000</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>Вр3 яч17*36</td>
		      <td>1,49
		      <td>1*3</td>
		      <td>374,5</td>
		      <td>371,52</td>
		      <td>250000</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>Вр3 яч 20*20</td>
		      <td>1,85
		      <td>1*3</td>
		      <td>464,5</td>
		      <td>460,8</td>
		      <td>250000</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>Вр4 яч10*10</td>
		      <td>5,8
		      <td>1*3</td>
		      <td>1411,4</td>
		      <td>1399,8</td>
		      <td>243000</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>Вр4 яч15*15</td>
		      <td>4
		      <td>1*3</td>
		      <td>974</td>
		      <td>966</td>
		      <td>243000</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>Вр4 яч20*20</td>
		      <td>3
		      <td>1*3</td>
		      <td>731</td>
		      <td>725</td>
		      <td>243000</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>Вр5 яч10*10</td>
		      <td>8,5
		      <td>1*3</td>
		      <td>2067,5</td>
		      <td>2050,5</td>
		      <td>243000</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>Вр5 яч15*15</td>
		      <td>5,9
		      <td>1*3</td>
		      <td>1435,7</td>
		      <td>1423,9</td>
		      <td>243000</td>
		      <td></td>
		   </tr>
		   <tr>
		      <td>Вр5 яч20*20</td>
		      <td>4,7
		      <td>1*3</td>
		      <td>1144,1</td>
		      <td>1134,7</td>
		      <td>243000</td>
		      <td></td>
		   </tr>
		</table>
		<table>
		   <caption>ПРОФНАСТИЛ ПОД РАЗМЕР, НА ЗАКАЗ</caption>
		   <tr>
		      <th rowspan="2" class="first">Размер, мм</th>
		      <th rowspan="2">Вес 1 п.м.</th>
		      <th rowspan="2">Рабочая ширина, мм</th>
		      <th colspan="3">Стоимость, тенге</th>
		      <th rowspan="2">Пимечание</th>
		   </tr>
		   <tr>
		      <td class="first">за 1 п.м.</td>
		      <td class="first">за 1 кв.м.</td>
		      <td class="first">тонна</td>
		   </tr>
		   <tr>
		      <td>0,4 С 8</td>
		      <td>4,05
		      <td>1150</td>
		      <td>1364,85</td>
		      <td>1186,82608695652</td>
		      <td>337000</td>
		      <td>Длина от 1 м. до 9 м.</td>
		   </tr>
		   <tr>
		      <td>0,4 С 15</td>
		      <td>4,05
		      <td>1134</td>
		      <td>1364,85</td>
		      <td>1207,83185840708</td>
		      <td>337000</td>
		      <td>Длина от 1 м. до 9 м.</td>
		   </tr>
		   <tr>
		      <td>0,4 НС 20</td>
		      <td>4,05
		      <td>1100</td>
		      <td>1364,85</td>
		      <td>1240,77272727273</td>
		      <td>337000</td>
		      <td>Длина от 1 м. до 9 м.</td>
		   </tr>
		   <tr>
		      <td>0,45 С 8</td>
		      <td>4,55
		      <td>1150</td>
		      <td>1460,55</td>
		      <td>1270,04347826087</td>
		      <td>321000</td>
		      <td>Длина от 1 м. до 9 м.</td>
		   </tr>
		   <tr>
		      <td>0,45 С 15</td>
		      <td>4,55
		      <td>1134</td>
		      <td>1460,55</td>
		      <td>1292,52212389381</td>
		      <td>321000</td>
		      <td>Длина от 1 м. до 9 м.</td>
		   </tr>
		   <tr>
		      <td>0,45 НС 20</td>
		      <td>4,55
		      <td>1100</td>
		      <td>1460,55</td>
		      <td>1327,77272727273</td>
		      <td>321000</td>
		      <td>Длина от 1 м. до 9 м.</td>
		   </tr>
		   <tr>
		      <td>0,50 С 8</td>
		      <td>5,05
		      <td>1150</td>
		      <td>1560,45</td>
		      <td>1356,91304347826</td>
		      <td>309000</td>
		      <td>Длина от 1 м. до 9 м.</td>
		   </tr>
		   <tr>
		      <td>0,50 С 15</td>
		      <td>5,05
		      <td>1134</td>
		      <td>1560,45</td>
		      <td>1380,92920353982</td>
		      <td>309000</td>
		      <td>Длина от 1 м. до 9 м.</td>
		   </tr>
		   <tr>
		      <td>0,50 НС 20</td>
		      <td>5,05
		      <td>1100</td>
		      <td>1560,45</td>
		      <td>1418,59090909091</td>
		      <td>309000</td>
		      <td>Длина от 1 м. до 9 м.</td>
		   </tr>
		   <tr>
		      <td>0,7 НС 20 (II сорт)</td>
		      <td>6,3
		      <td></td>
		      <td>1262</td>
		      <td>1147,27272727273</td>
		      <td>200000</td>
		      <td>Длина от 1,8 м до 3,6 м</td>
		   </tr>
		</table>

	</div>
	<button id="cmd">Преобразовать в PDF</button>
</body>
</html>